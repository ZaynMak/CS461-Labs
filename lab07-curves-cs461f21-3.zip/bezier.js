function BezierCurve(points) {
  /**
  * Constructs a Bezier curve representation using the 4 control points
  * defined in the incoming 'points' array.
  *
  * @param points - an Array of vec2's, which MUST have a length of 4 (for cubic Bezier curves)
  *                 In other words, points = [q0,q1,q2,q3] from the lecture notes
  *
  * Note: the curve is parametrized between [0,1] so at t = 0,
  * we should get q0, and at t = 1, we should get q3.
  **/
  console.assert( points.length == 4 ); // we want cubic bezier curves
  this.points = points; // simply store the array of four vec2's
}

BezierCurve.prototype.draw = function(context,A,depth) {

  // default to a straight line until the bezier evaluation is defined
  this.render(depth);

  // draw the control points: drawPoint is defined in animation.js
  for (let i = 0; i < this.points.length; i++) {
    if (i == 0 || i == this.points.length-1) color = '#000000'; // black for fixed endpoints
    else color = '#E5989B'; // pink-ish
    drawPoint( context , A , this.points[i] , 10 , color );
  }

  // draw the dashed lines controlling the derivatives at the endpoints
  // the drawLine function is defined in animation.js
  context.setLineDash([2,3]);
  drawLine( context , A , this.points[0] , this.points[1] );
  drawLine( context , A , this.points[2] , this.points[3] );
  context.setLineDash([]); // re-set to solid lines
}

BezierCurve.prototype.evaluate = function(t) {
  /**
  * Evaluates a Bezier curve at a parameter value t
  * using de Casteljau's algorithm.
  *
  * @param t - input parameter in [0,1] to evaluate the curve.
  * @return p - a vec2 with the coordinates of the evaluated curve.
  *
  * Note that the Bezier curve is paramterized between [0,1].
  **/

  // evaluate the Bezier curve at a time value t
  let p = vec2.create();

  // the following does linear interpolation between the curve endpoints
  // this is not what we want!!
  if (false) { // set this to false once you have your code working
    vec2.lerp( p , this.points[0] , this.points[3] , t );
    return p;
  }

  // here are the control points (each is a vec2) as defined in the notes
  let q0 = this.points[0];
  let q1 = this.points[1];
  let q2 = this.points[2];
  let q3 = this.points[3];

  // step 1: compute the three points: m0, m1 and m2 in lecture notes
  let m0 = vec2.create();
  let m1 = vec2.create();
  let m2 = vec2.create();

  vec2.lerp(m0, q0, q1, t);
  vec2.lerp(m1, q1, q2, t);
  vec2.lerp(m2, q2, q3, t);

  // step 2: compute the next set of points: r0, r1 in lecture notes
  let r0 = vec2.create();
  let r1 = vec2.create();

  vec2.lerp(r0, m0, m1, t);
  vec2.lerp(r1, m1, m2, t);


  // step 3: compute the final point: p(t) in lecture notes
  vec2.lerp(p, r0, r1, t);

  return p;

}

BezierCurve.prototype.drawLine = function( p , q ) {
  // the variables 'context' and 'tranformation' are global variables initialized in index.html
  // and set in the Animation class constructor
  drawLine(context,transformation,p,q); // drawLine is defined in animation.js
}

BezierCurve.prototype.render = function( depth ) {
  /**
   * Renders a Bezier curve recursively until a specified
   * depth is reached. When this depth is reached, then
   * lines are drawn between all the control points.
   * 
   * Otherwise, de Casteljau's algorithm is used to divide
   * the original curve into two new curves at t = 0.5.
   * 
   * @param depth - maximum recursion depth (depth of 0 means terminate recursion and connect the control points by calling drawLine)
  **/
  // use the context functions to draw a bezier curve
  // this is not what we want!!
  if (false) { // set this to false once you have your code working
    drawBezier(this.points);
    return;
  }

  // here are the control points (each is a vec2) as defined in the notes
  let q0 = this.points[0];
  let q1 = this.points[1];
  let q2 = this.points[2];
  let q3 = this.points[3];

  // step 1: check if base case is reached (depth is zero)
  // when the base case is reached, you should use the 'drawLine'
  // function (above) to draw the lines connecting the control points
  if (depth == 0) { // if depth is 0, then draws the lines
    this.drawLine(q0 , q1);
		this.drawLine( q1 , q2);
		this.drawLine( q2 , q3);
    return;
  }


// step 1: compute the three points: m0, m1 and m2 in lecture notes
  let m0 = vec2.create();
  let m1 = vec2.create();
  let m2 = vec2.create();

  vec2.lerp(m0, q0, q1, 0.5);
  vec2.lerp(m1, q1, q2, 0.5);
  vec2.lerp(m2, q2, q3, 0.5);

  // step 2: compute the next set of points: r0, r1 in lecture notes
  let r0 = vec2.create();
  let r1 = vec2.create();

  vec2.lerp(r0, m0, m1, 0.5);
  vec2.lerp(r1, m1, m2, 0.5);


  // step 3: compute the final point: p(0.5) in lecture notes
  let p = vec2.create();
  vec2.lerp(p, r0, r1, 0.5);

  // step 5: create the two new Bezier curves
  // INSERT CODE HERE
  let curve0 = new BezierCurve([q0, m0, r0, p]);
  let curve1 = new BezierCurve([p, r1, m2, q3]);

  // step 6: recurse the rendering for the two new curves
  //         (make sure to decrement the depth so the recursion terminates at depth = 0)
	curve0.render(depth-1);
	curve1.render(depth-1);
}
