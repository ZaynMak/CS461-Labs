function Animation(canvasID) {
  /**
  * Constructs an instance of a class used to animate a bouncing ball.
  *
  * @param canvasID - HTML id of the canvas where the animation will be drawn
  *
  * At the end of the constructor, there are TWO Bezier curves defined
  *   this.curves[0] describes the downards motion of the ball
  *   this.curves[1] describes the upwards motion of the ball
  *
  * Each curve is a cubic Bezier curve, and is defined by FOUR control points.
  *
  **/
  // initialize the canvas and context
  this.canvas  = document.getElementById(canvasID);
  this.context = this.canvas.getContext('2d');

  // load the pixar ball image
  this.ball = document.createElement('img');
  this.ball.src = 'pixarball.png';

  // create the first curve to represent downwards ball motion
  this.curves = new Array(2);
  this.curves[0] = new BezierCurve(
    [
      vec2.fromValues(0,1),
      vec2.fromValues(0.125,0.625),
      vec2.fromValues(0.375,0.125),
      vec2.fromValues(0.5,0)
    ]
  );

  // create second curve to represent upwards ball motion
  this.curves[1] = new BezierCurve(
    [
      vec2.fromValues(0.5,0),
      vec2.fromValues(0.625,0.125),
      vec2.fromValues(0.875,0.625),
      vec2.fromValues(1,1)
    ]
  );

  // transformation from physical space to canvas space: reflect, scale, translate
  this.transformation = mat3.create();
  this.transformation[4] = -1; // reflect the y-axis
  let f = 0.8; // fraction of the canvas taken up by bezier curves
  let offset = vec2.fromValues( 0.5*(1.0-f)*this.canvas.width, 0.5*(1.0-f)*this.canvas.height );
  mat3.scale( this.transformation , this.transformation , vec2.fromValues(f*this.canvas.width , f*this.canvas.height ) );
  let translation = mat3.create();
  mat3.fromTranslation( translation , vec2.fromValues(offset[0],f*this.canvas.height+offset[1]) );
  mat3.multiply(this.transformation,translation,this.transformation);

  // set the global variables
  transformation = this.transformation;
  context = this.context;

  // save the inverse transformation (needed for 'picking' - i.e. clicking a canvas location and associating it with a control point)
  this.inverseTransformation = mat3.create();
  mat3.invert( this.inverseTransformation , this.transformation );

  // initialize parameters and draw
  this.time = 0.0;
  this.dt   = 0.025; // change this to control the animation speed
  this.draw();

  // set the canvas callbacks
  this.dragging = false;
  let animation = this;
  this.canvas.onmousedown = function(event) {
    animation.dragging = true;
  }

  this.canvas.onmousemove = function(event) {

    // get the pixel coordinates of the mouse
    const rect = animation.canvas.getBoundingClientRect()
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;

    // get the closest control point
    let point = undefined;
    for (let i = 0; i < animation.curves.length; i++) {

      // curve endpoints (black points are frozen) so only consider j = 1,2
      for (let j = 1; j < animation.curves[i].points.length-1; j++) {

        // compute canvas pixel coordinates of this control point
        let p = mvm3h(animation.transformation,animation.curves[i].points[j]);

        // check if canvas coordinates are close to mouse location
        let d = Math.sqrt( (p[0]-x)*(p[0]-x) + (p[1]-y)*(p[1]-y) );
        if (d < 20) { // 20 is a reasonable tolerance for this
          point = animation.curves[i].points[j];
        }
      }
    }

    if (!animation.dragging) return;
    if (point == undefined) return;

    // set the control point coordinates from the mouse (canvas) coordinates
    let q = mvm3h(animation.inverseTransformation,vec2.fromValues(x,y));
    point[0] = q[0];
    point[1] = q[1];

    // redraw the two curves!
    animation.draw();
  }

  this.canvas.onmouseup = function(event) {
    // we are no longer dragging when the mouse is released
    animation.dragging = false;
  }
}

Animation.prototype.draw = function() {
  // draw the curves using the recursive depth specified by the HTML input
  let depth = document.getElementById('input-render-depth').value;
  this.context.clearRect(0,0,this.canvas.width,this.canvas.height);
  for (let i = 0; i < this.curves.length; i++) {
    this.curves[i].transformation = this.transformation;
    this.curves[i].context = this.context;
    this.curves[i].draw(this.context,this.transformation,depth);
  }
}

Animation.prototype.run = function () {

  // draw the scene
  this.draw();

  // update to the current time
  this.time += this.dt;

  // determine which curve we are on (downwards or upwards?)
  // ball is bouncing down if time < 0.5, bouncing up if time > 0.5
  let curve = this.curves[0];
  if (this.time > 0.5) curve = this.curves[1];
  
  // convert the time value to a parameter value (t) for the desired curve
  // this gives a value for t between [0,1]
  let t = (this.time - curve.points[0][0]) / (curve.points[3][0] - curve.points[0][0]);

  // evaluate the curve at the appropriate parameter value (t)
  let p = curve.evaluate(t);

  // draw the ball, along with a red tracer along the curve
  let ball  = vec2.fromValues(0.5,p[1]);
  let q = mvm3h(this.transformation,ball);

  drawPoint( this.context , this.transformation , p , 10 , 'red' );
  
  //inserted code
	if ((this.time > 0.35 && this.time < 0.45) || (this.time > 0.55 && this.time < 0.65)) {
		this.context.drawImage(this.ball,0,0,this.ball.width,this.ball.height,q[0]-25,q[1]-25,60,40);
	} else if (this.time >= 0.45 && this.time <= 0.55) {
		this.context.drawImage(this.ball,0,0,this.ball.width,this.ball.height,q[0]-25,q[1]-25,70,30);
	} else{
		this.context.drawImage(this.ball,0,0,this.ball.width,this.ball.height,q[0]-25,q[1]-25,50,50);
	}
  

  if (this.time < 1.0) {
    // request the next time
    let animation = this;
    requestAnimationFrame( function() { animation.run() } );
  }
}

function mvm3h(A,x) {
  // matrix-vector-multiplication for 3x3 matrix with a 2d vector augmented to homogeneous coordinates
  // multiplies a 3x3 transformation matrix A by a vector (x,1) where x is 2d vector
  // thus augmenting x in homogeneous coordinates (third component = 1)
  // this is just short-hand to make it easier to write out the transformations
  // (i.e. not having to write vec2.create(), vec2.transformMat3 all the time)
  let y = vec2.create();
  vec2.transformMat3(y,x,A);
  return y;
}

let drawLine = function( context , A , p , q ) {

  // compute screen coordinates
  let ps = mvm3h(A,p);
  let qs = mvm3h(A,q);

  // draw the line
  context.beginPath();
  context.moveTo( ps[0] , ps[1] );
  context.lineTo( qs[0] , qs[1] );
  context.stroke();
}

let drawPoint = function( context , A , p , radius , color ) {

  // compute screen coordiantes
  let ps = mvm3h( A , p );

  // draw a filled circle
  context.beginPath();
  context.strokeStyle = "#000000";
  context.fillStyle   = color;
  context.arc(ps[0],ps[1], radius, 0, 2.0*Math.PI, true);
  context.fill();
  context.stroke();
}

let drawBezier = function( points ) {
  // the 2d context knows how to draw bezier curves
  // so this should be useful for debugging :)
  let q = new Array(points.length);
  for (let i = 0; i < points.length; i++)
    q[i] = mvm3h(transformation,points[i]);
  context.beginPath();
  context.moveTo( q[0][0] , q[0][1] );
  context.bezierCurveTo( q[1][0] , q[1][1] ,
                         q[2][0] , q[2][1] ,
                         q[3][0] , q[3][1]
  );
  context.stroke();
}