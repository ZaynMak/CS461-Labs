function getTerrain(scale, sizeX, sizeY, noiseSizeX, noiseSizeY, maxHeight) {

	// generates a mountainous terrain with vertices, indices and normal
	// found here: https://github.com/keunhong/webgl-flightsim

	// make array to store vertices
	var vertices = new Array(sizeX);
	for (var i = 0; i < sizeY; i++)
		vertices[i] = new Array(sizeY);

	// generate noise and smooth
	var noise = rawNoise2D(Math.floor(2+noiseSizeX), Math.floor(2+noiseSizeY), maxHeight);
	noise = smoothNoise2D(noise);

	for (var x = 0; x < sizeX; x++) {
		for (var y = 0; y < sizeY; y++) {
			samplex = x*scaleRange(0, sizeX-1, 0, (noiseSizeX-2));
			sampley = y*scaleRange(0, sizeY-1, 0, (noiseSizeY-2));
			var sample = bilinearInterpolate(samplex, sampley, noise);
			var xcoord = scale/sizeX*x;
			var ycoord = scale/sizeY*y;
			var zcoord = sample;

			vertices[x][y] = vec3.fromValues(xcoord, ycoord, zcoord);
		}
	}

	var coordinates = [];
	var normals     = [];
	var triangles   = [];
	for (var x = 0; x < sizeX-1; x++) {
		for (var y = 0; y < sizeY-1; y++) {

			// triangle 1
			var v1 = vec3.clone(vertices[x][y]);
			var v2 = vec3.clone(vertices[x+1][y]);
			var v3 = vec3.clone(vertices[x][y+1]);
			var v4 = vec3.clone(vertices[x+1][y+1]);

			var top = vec3.create(); vec3.subtract(top,v2, v1);
			var left = vec3.create(); vec3.subtract(left,v1, v3);
			var bottom = vec3.create(); vec3.subtract(bottom,v4, v3);
			var right = vec3.create(); vec3.subtract(right,v4, v2);

			let t = coordinates.length / 3;
			coordinates.push(v1[0], v1[1], v1[2]);
			coordinates.push(v2[0], v2[1], v2[2]);
			coordinates.push(v3[0], v3[1], v3[2]);
			triangles.push( t , t+1 , t+2 );

			// create normals
			var normal = vec3.create();
			vec3.cross(normal,left, top);
			vec3.normalize(normal,normal);
			normals.push(normal[0], normal[1], normal[2]);
			normals.push(normal[0], normal[1], normal[2]);
			normals.push(normal[0], normal[1], normal[2]);

			// triangle 2
			coordinates.push(v3[0], v3[1], v3[2]);
			coordinates.push(v2[0], v2[1], v2[2]);
			coordinates.push(v4[0], v4[1], v4[2]);
			triangles.push( t+3 , t+4 , t+5 );

			// create normals
			normal = vec3.create();
			vec3.cross(normal,bottom, right);
			vec3.normalize(normal,normal);
			normals.push(normal[0], normal[1], normal[2]);
			normals.push(normal[0], normal[1], normal[2]);
			normals.push(normal[0], normal[1], normal[2]);
		}
	}

	return {'vertices': coordinates, 'triangles': triangles, 'normals': normals};
}

function scaleRange(fromMin, fromMax, toMin, toMax) {
	return (toMax-toMin-1)/(fromMax-fromMin-1);
}

function rawNoise2D(numPointsX, numPointsY, max) {

	numPointsX += 2;
	numPointsY += 2;

	var result = new Array(numPointsX);
	for (var i = 0; i < numPointsX; i++)
		result[i] = new Array(numPointsY);

	for (var x = 0; x < numPointsX; x++)
	for (var y = 0; y < numPointsY; y++)
		result[x][y] = Math.random()*max;

	return result;
}

function smoothNoise2D(rawNoise) {
	var numPointsX = rawNoise.length-2;
	var numPointsY = rawNoise[0].length-2;

	var result = new Array(numPointsX);
	for (var i = 0; i < numPointsX; i++)
		result[i] = new Array(numPointsY);

	for (var x = 1; x < numPointsX; x++) {
		for (var y = 1; y < numPointsY; y++) {
			var corners = (rawNoise[x-1][y-1] + rawNoise[x+1][y-1] + rawNoise[x-1][y+1] + rawNoise[x+1][y+1]) / 16;
			var sides = (rawNoise[x-1][y] + rawNoise[x+1][y] + rawNoise[x][y-1] + rawNoise[x][y+1])/8;
			var center = rawNoise[x][y] / 4;
			result[x-1][y-1] = corners + sides + corners;
		}
	}
	return result;
}

function bilinearInterpolate(x, y, s) {
	x0 = Math.floor(x);
	y0 = Math.floor(y);
	x1 = Math.ceil(x);
	y1 = Math.ceil(y);

	// handle edge cases
	if (x == 0) x1 += 1
	if (y == 0) y1 += 1;

	// add one for edge cases
	q00 = s[x0+1][y0+1];
	q01 = s[x0+1][y1+1];
	q10 = s[x1+1][y0+1];
	q11 = s[x1+1][y1+1];

	return q00/((x1-x0)*(y1-y0)) * (x1-x) * (y1-y) +
			q10/((x1-x0)*(y1-y0)) * (x-x0) * (y1-y) +
			q01/((x1-x0)*(y1-y0)) * (x1-x) * (y-y0) +
			q11/((x1-x0)*(y1-y0)) * (x-x0) * (y-y0)
}

function computeNormals(vertices,triangles) {

	const np = vertices.length/3;
	const nt = triangles.length/3;

	// allocate the data
  valency = new Uint8Array(np);
  normals = new Float32Array(vertices.length);

  // add the contribution of every triangle to the vertices
  for (var i = 0; i < nt; i++) {
    // retrieve the indices of the triangle and add the valency contributions
    const t0 = triangles[3*i  ];
    const t1 = triangles[3*i+1];
    const t2 = triangles[3*i+2];

    // retrieve the coordinates of the points
    const p0x = vertices[ 3*t0    ];
    const p0y = vertices[ 3*t0 +1 ];
    const p0z = vertices[ 3*t0 +2 ];
    const p1x = vertices[ 3*t1    ];
    const p1y = vertices[ 3*t1 +1 ];
    const p1z = vertices[ 3*t1 +2 ];
    const p2x = vertices[ 3*t2    ];
    const p2y = vertices[ 3*t2 +1 ];
    const p2z = vertices[ 3*t2 +2 ];

    const ux = p1x - p0x;
    const uy = p1y - p0y;
    const uz = p1z - p0z;
    const vx = p2x - p0x;
    const vy = p2y - p0y;
    const vz = p2z - p0z;

    // compute the triangle normal
    let nx = uy*vz - uz*vy;
    let ny = uz*vx - ux*vz;
    let nz = ux*vy - uy*vx;

    // add the contribution to every vertex
    normals[3*t0] += nx; normals[3*t0+1] += ny; normals[3*t0+2] += nz;
    normals[3*t1] += nx; normals[3*t1+1] += ny; normals[3*t1+2] += nz;
    normals[3*t2] += nx; normals[3*t2+1] += ny; normals[3*t2+2] += nz;

    valency[t0]++;
    valency[t1]++;
    valency[t2]++;
  }

  // average the point normals
  for (var i = 0; i < np; i++) {
    // compute the average
    normals[3*i  ] /= valency[i];
    normals[3*i+1] /= valency[i];
    normals[3*i+2] /= valency[i];

    // normalize
    const nx = normals[3*i];
    const ny = normals[3*i+1];
    const nz = normals[3*i+2];

    const n = Math.sqrt( nx*nx + ny*ny + nz*nz );
    normals[3*i  ] /= n;
    normals[3*i+1] /= n;
    normals[3*i+2] /= n;
  }
	return normals;
}

let reshapeArray = function(rawData) {
  let data = [];
  for (var i = 0, chunk = 10000; i < rawData.length; i += chunk) {
    data = Array.prototype.concat.apply(data, rawData.slice(i, i + chunk));
  }
  return data;
}

multiplyVec3 = function(A,x) {
	// multiplies the top-left 3x3 submatrix of a 4x4 matrix by a 3d vector
	return vec3.fromValues(
		A[0]*x[0] + A[4]*x[1] + A[8]*x[2] ,
		A[1]*x[0] + A[5]*x[1] + A[9]*x[2] ,
		A[2]*x[0] + A[6]*x[1] + A[10]*x[2]
	);
}

multiplyVec4 = function(A,x) {
	return vec3.fromValues(
		A[0]*x[0] + A[4]*x[1] + A[8]*x[2]  + A[12]*x[3],
		A[1]*x[0] + A[5]*x[1] + A[9]*x[2]  + A[13]*x[3],
		A[2]*x[0] + A[6]*x[1] + A[10]*x[2] + A[14]*x[3],
		A[3]*x[0] + A[7]*x[1] + A[11]*x[2] + A[15]*x[3]
	);
}

function preprocessMike(terrain) {

	mike.vertices = reshapeArray(mike.vertices);
	mike.triangles = reshapeArray(mike.triangles);

	// compute the center of the bounding box
	let center = vec3.create();
	let xmin = vec3.fromValues( 1e20, 1e20, 1e20);
	let xmax = vec3.fromValues(-1e20,-1e20,-1e20);
	for (let d = 0; d < 3; d++) {
		for (let i = 0; i < mike.vertices.length/3; i++) {
			if (mike.vertices[3*i+d] < xmin[d]) xmin[d] = mike.vertices[3*i+d];
			if (mike.vertices[3*i+d] > xmax[d]) xmax[d] = mike.vertices[3*i+d];
		}
		center[d] = 0.5*( xmin[d] + xmax[d] );
	}

	// pick a random vertex on the terrain
	let idx = Math.floor( Math.random() * terrain.vertices.length / 3 );
	idx = Math.floor( 0.5 * terrain.vertices.length / 3 );

	let x = terrain.vertices[3*idx  ];
	let y = terrain.vertices[3*idx+1];
	let z = terrain.vertices[3*idx+2];

	let modelMatrix = mat4.create();

	// translate to the origin
	mat4.fromTranslation(modelMatrix,vec3.fromValues(-center[0],-center[1],-center[2]) );

	// rotate to align upwards
	let rotation = mat4.create();
	mat4.fromXRotation( rotation , Math.PI/2.0 );
	mat4.multiply( modelMatrix , rotation , modelMatrix );

	// scale the model
	scale = 0.001;
	let S = mat4.create();
	mat4.fromScaling( S , vec3.fromValues(scale,scale,scale) );
	mat4.multiply( modelMatrix , S , modelMatrix );

	// translate to the desired point
	let translation = mat4.create();
	mat4.fromTranslation( translation , vec3.fromValues(x,y,z+scale*Math.abs(center[1]-xmin[1])) );
	mat4.multiply( modelMatrix , translation , modelMatrix );

	// transform the vertices
	for (let i = 0; i < mike.vertices.length/3; i++) {
		let v = vec4.fromValues( mike.vertices[3*i] , mike.vertices[3*i+1] , mike.vertices[3*i+2] , 1.0 );
		v = multiplyVec4( modelMatrix , v );

		mike.vertices[3*i  ] = v[0];
		mike.vertices[3*i+1] = v[1];
		mike.vertices[3*i+2] = v[2];
	}

	mike.normals = computeNormals(mike.vertices,mike.triangles);
}
