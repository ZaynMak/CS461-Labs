$(document).bind('keydown', function(e) {
	e.preventDefault();

	var key = e.keyCode;

	if (key == 38) // up arrow
		pitchAngularVelocity = -0.30;
	if (key == 40) // down arrow
		pitchAngularVelocity = 0.30;
	if (key == 37) // right arrow
		rollAngularVelocity = -0.30;
	if (key == 39)// left arrow
		rollAngularVelocity = 0.30;
	if (key == 189) // - (slow down)
		velocity -= 0.01;
	if (key == 187) // + (speed up)
		velocity += 0.01;
});

$(document).bind('keyup', function(e) {
	e.preventDefault();
	var key = e.keyCode;
	if (key == 38 || key == 40) // up/down arrows
		pitchAngularVelocity = 0;
	if (key == 37 || key == 39) // right/left arrows
		rollAngularVelocity = 0;
});

function getShader(gl,type,source) {

	// set shader source and compile
	var shader = gl.createShader(type);
	gl.shaderSource(shader, source);
	gl.compileShader(shader);

	// check if there was an error
	if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
		alert(gl.getShaderInfoLog(shader));
		return undefined;
	}

	return shader;
}

function createProgram(gl, vertexShaderSource, fragmentShaderSource) {

	var vertexShader = getShader(gl,gl.VERTEX_SHADER,vertexShaderSource);
	var fragmentShader = getShader(gl,gl.FRAGMENT_SHADER,fragmentShaderSource);

	var program = gl.createProgram();
	gl.attachShader(program, vertexShader);
	gl.attachShader(program, fragmentShader);
	gl.linkProgram(program);

	if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
	  alert("could not link shader program.");
	}
	gl.useProgram(program);

	// set vertex position attribute
	program.vertexPositionAttribute = gl.getAttribLocation(program, "a_VertexPosition");
	gl.enableVertexAttribArray(program.vertexPositionAttribute);

	// set vertex normal attribute
	program.vertexNormalAttribute = gl.getAttribLocation(program, "a_VertexNormal");
	gl.enableVertexAttribArray(program.vertexNormalAttribute);

	return program;
}

let vertexShaderSource =`
attribute vec3 a_VertexPosition;
attribute vec3 a_VertexNormal;

uniform mat4 u_PerspectiveMatrix;
uniform mat4 u_ViewMatrix;
uniform mat4 u_ModelMatrix;
uniform mat4 u_NormalMatrix;

uniform float u_Mike; // flag whether or not this is mike wazowski
uniform vec3 u_lightDirection;

vec3 ambientColor = vec3(0.4,0.4,0.4);
vec3 lightPosition = vec3(10,0,3);

varying vec3 v_Color;

void main(void) {

	// transform the vertex position
	gl_Position = u_PerspectiveMatrix * u_ViewMatrix * vec4(a_VertexPosition, 1.0 );

	// calculate direction of light
	vec3 lightDir = u_lightDirection;
	//vec3 lightDir = normalize( lightPosition - a_VertexPosition.xyz );

	// compute the cosine of the angle between the model normal and lighting direction
	vec3 normal = a_VertexNormal;
	float cosine = max(dot(normal, lightDir), 0.0);

	// compute the vertex color
	if (u_Mike > 0.0) {
		// coloring mike wazowski
		v_Color = vec3(0.5,0.7,0.5) * cosine;
		return;
	}

	if (a_VertexPosition.z > 1.2) {
		v_Color =  ambientColor + vec3(1.0,1.0,1.0) * cosine;
	}
	else if (a_VertexPosition.z > 0.8) {
		v_Color =  ambientColor + vec3(0.5,0.5,0.5) * cosine;
	}
	else
		v_Color = ambientColor + vec3(0.2,0.5,0.2) * cosine;
}`;

let fragmentShaderSource = `
precision highp float;

varying vec3 v_Color;

void main(void) {
	// use the color from the vertex shader
	gl_FragColor = vec4(v_Color, 1.0);
}`;

function FlightSimulator(canvasID) {
  
	// initialize the canvas, the WebGL context and objects to render
	this.canvas = document.getElementById(canvasID);
	this.canvas.width = 0.9*window.innerWidth;

	this.gl = this.canvas.getContext('webgl') || this.canvas.getContext('experimental-webgl');
	this.objects = new Array();

	// add the terrain object
	var terrain = getTerrain(20.0 , 50 , 50 , 100 , 100 , 2.0);
	this.addObject(terrain , 'terrain' );

	// add mike wazowski
	preprocessMike(terrain);
	this.addObject(mike, 'mike' );

	// create the shader program
	this.program = createProgram(this.gl,vertexShaderSource,fragmentShaderSource);

	// clear the canvas color
	this.gl.clearColor(0.8, 0.7, 1.0, 1.0); // purpley-sky
	this.gl.enable(this.gl.DEPTH_TEST);

	// initialize the dynamics
	this.position = vec3.fromValues(10.0, 0.0, 2.0);
	this.forward  = vec3.fromValues(0,1,0);
	this.up       = vec3.fromValues(0,0,1);
	this.time     = 0.0;
}

FlightSimulator.prototype.addObject = function(mesh, name, modelMatrix) {

	// save the base color of the object and the transformation
	mesh.modelMatrix = modelMatrix;
	mesh.name = name;

	// dereference gl context to make life easier
	let gl = this.gl;

	// create vertex position buffer
	mesh.positionBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, mesh.positionBuffer);
	gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(mesh.vertices), gl.STATIC_DRAW);

	// create triangle index buffer
	mesh.triangleBuffer = gl.createBuffer();
	gl.bindBuffer( gl.ELEMENT_ARRAY_BUFFER , mesh.triangleBuffer );
	gl.bufferData( gl.ELEMENT_ARRAY_BUFFER , new Uint16Array(mesh.triangles) , gl.STATIC_DRAW );

	// create vertex normal buffer
	mesh.normalBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, mesh.normalBuffer);
	gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(mesh.normals), gl.STATIC_DRAW);

	// add the mesh to the simulator
	this.objects.push(mesh);
}

var velocity = 0.25;
var pitchAngularVelocity = 0;
var rollAngularVelocity  = 0;
var request_id;

FlightSimulator.prototype.animate = function() {

	// setup the animation frame request
	let simulator = this;
	request_id = requestAnimationFrame( function() { simulator.animate(); } );

	// draw the scene
  try {
	  this.draw();
  }
  catch(err) {
    window.cancelAnimationFrame(request_id);
  }

	var now = new Date().getTime();
	if (this.time != 0.0) {

		// delta-time (dt) in seconds
	  var delta = (now - this.time)/1000.0;

		// move forward
		this.position[0] += delta * velocity * this.forward[0];
		this.position[1] += delta * velocity * this.forward[1];
		this.position[2] += delta * velocity * this.forward[2];

		// calculate how much pitch and roll change (delta-roll, delta-pitch)
		droll  = delta * rollAngularVelocity;
		dpitch = delta * pitchAngularVelocity;

		// calculate how much yaw changes based on the current orientation (delta-yaw)
		// this isn't the most physically accurate calculation, but it works
		let wing = vec3.create();
		vec3.cross( wing , this.forward , vec3.fromValues(0,0,1) );
		vec3.normalize(wing,wing);
		let yawAngularVelocity = velocity * vec3.dot( wing , this.up );
		let dyaw = -delta * yawAngularVelocity;

		// yaw according to roll: update forward vector
		var rotateMatrix = mat4.create();
		mat4.rotate( rotateMatrix , rotateMatrix , dyaw , this.up );
		this.forward = multiplyVec3(rotateMatrix,this.forward);

		// calculate pitch: update up and forward vectors
		right = vec3.create();
		vec3.cross(right,this.forward, this.up);
		mat4.identity(rotateMatrix);
		mat4.rotate(rotateMatrix, rotateMatrix, dpitch , right);
		this.up      = multiplyVec3(rotateMatrix,this.up);
		this.forward = multiplyVec3(rotateMatrix,this.forward);
		vec3.normalize(this.forward,this.forward);

		// calculate roll: update up vector
		mat4.identity(rotateMatrix);
		mat4.rotate(rotateMatrix, rotateMatrix, droll , this.forward);
		this.up = multiplyVec3(rotateMatrix,this.up);
		vec3.normalize(this.up,this.up);
	}
	this.time = now;
}

function writeMatrixUniform( gl , program , name , matrix ) {

	let location = gl.getUniformLocation(program,name);
	gl.uniformMatrix4fv( location , false , matrix );
}

function calculatePerspectiveMatrix( fovy , width , height , znear , zfar ) {
  // 'fovy' is the vertical field-of-view
  // 'width' and 'height' are the width and height of the canvas
  // 'znear' and 'zfar' are the locations of the near and far planes (n and f)

    // calculate and return perspective projection matrix here

    let persp = mat4.create();
		const a = width/height;
    persp[0] = 1/(a * Math.tan(fovy/2));
    persp[5] = 1/(Math.tan(fovy/2));
    persp[10] = -(zfar + znear)/(zfar - znear); 
    persp[11] = -1.0;
    persp[14] = -(2 * zfar * znear)/(zfar - znear);
		persp[15] = 0;
  return persp;
}

function calculateViewMatrix( position , forward , up ) {
  // 'position' is the position of the airplane
  // 'forward' is the direction the airplane is pointing towards
  // 'up' is the up direction of the airplane

    // calculate and return view matrix here
  let w = vec3.create();
  let u = vec3.create();
  let v = vec3.create();
	let temp = vec3.create();
	let temp2 = vec3.create();

	vec3.normalize(w, forward);
	vec3.scale(w, w, -1);

  vec3.cross(temp, up, w);
  vec3.normalize(u, temp);

	vec3.cross(v, w, u);
   

  
  let viewM = mat4.create();
  viewM[0] = u[0];
  viewM[1] = v[0];
  viewM[2] = w[0];
  viewM[4] = u[1];
  viewM[5] = v[1];
  viewM[6] = w[1];
	viewM[8] = u[2];
  viewM[9] = v[2];
  viewM[10] = w[2];

  
  let eye = mat4.create();
  eye[12] = -position[0];
  eye[13] = -position[1];
  eye[14] = -position[2];

	mat4.multiply(viewM, viewM, eye);	

  return viewM
}

FlightSimulator.prototype.draw = function() {

	// draw the scene
	let gl = this.gl;

	// set viewport
	gl.viewport(0, 0, this.canvas.width, this.canvas.height);

	// clear screen
	gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

	// calculate perspective matrix
	let perspectiveMatrix = calculatePerspectiveMatrix( Math.PI/4.0 , this.canvas.width , this.canvas.height , 0.1, 1000.0 );
  if (perspectiveMatrix == undefined) console.error('implement perspective matrix calculation!');
	gl.uniformMatrix4fv( gl.getUniformLocation(this.program,'u_PerspectiveMatrix') , false, perspectiveMatrix);

	// calculate view matrix
	let viewMatrix = calculateViewMatrix( this.position , this.forward , this.up );
  if (viewMatrix == undefined) console.error('implement view matrix calculation!');
	gl.uniformMatrix4fv( gl.getUniformLocation(this.program,'u_ViewMatrix') , false , viewMatrix );

	let normalMatrix = mat4.create();
	mat4.invert( normalMatrix , viewMatrix );
	mat4.transpose( normalMatrix , normalMatrix );
	gl.uniformMatrix4fv( gl.getUniformLocation(this.program,'u_NormalMatrix') , false , normalMatrix );

	// directional light
	var lightingDirection = this.forward.slice();
	vec3.scale(lightingDirection,lightingDirection,-1.0);
	gl.uniform3fv( gl.getUniformLocation(this.program,'u_lightDirection') , lightingDirection );

	// model specific uniforms
	for (let i = 0; i < this.objects.length; i++) {

		// retrieve the mesh object
		let mesh = this.objects[i];

		// set the color to the shader: if mike wazowski, we will use a constant color
		const mike = mesh.name == 'mike' ? 1.0 : -1.0;
		gl.uniform1f( gl.getUniformLocation(this.program,'u_Mike') , mike );

		// bind the position buffer
		gl.bindBuffer(gl.ARRAY_BUFFER, mesh.positionBuffer);
		gl.vertexAttribPointer(this.program.vertexPositionAttribute, 3 , gl.FLOAT, false, 0, 0);

		// bind the normal buffer
		gl.bindBuffer(gl.ARRAY_BUFFER, mesh.normalBuffer);
		gl.vertexAttribPointer(this.program.vertexNormalAttribute, 3 , gl.FLOAT, false, 0, 0);

		// draw the triangles in the model
		gl.bindBuffer( gl.ELEMENT_ARRAY_BUFFER , mesh.triangleBuffer );
		gl.drawElements( gl.TRIANGLES , mesh.triangles.length , gl.UNSIGNED_SHORT , 0 );
	}

}
