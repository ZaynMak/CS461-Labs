function compileShader(gl, shaderSource, type) {
  let shader = gl.createShader(type);
  gl.shaderSource(shader, shaderSource);
  gl.compileShader(shader);

  if (! gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    var error = gl.getShaderInfoLog(shader);
    gl.deleteShader(shader);
    throw "Unable to compile " + (type === gl.VERTEX_SHADER ? 'vertex': 'fragment') + " shader: " + error;
  }

  return shader;
}

function compileProgram( gl , vertexShaderSource , fragmentShaderSource ) {

  let vertexShader = compileShader(gl, vertexShaderSource, gl.VERTEX_SHADER);
  let fragmentShader = compileShader(gl, fragmentShaderSource, gl.FRAGMENT_SHADER);

  let program = gl.createProgram();
  gl.attachShader(program, vertexShader);
  gl.attachShader(program, fragmentShader);

  gl.linkProgram(program);

  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    throw "Unable to compile the shader program: " + gl.getProgramInfoLog(program);
  }

  gl.useProgram(program);
  return program;
}

// computes a rotation matrix of a vector (X,Y) on the unit sphere using quaternions
function rotation(X, Y) {
  let X2 = X*X, Y2 = Y*Y,
    q  = 1 + X2 + Y2,
    s  = 1 - X2 - Y2,
    r2 = 1/(q*q), s2 = s*s,
    A = (s2 + 4*(Y2 - X2))*r2,
    B = -8*X*Y*r2,
    C = 4*s*X*r2,
    D = (s2 + 4*(X2 - Y2))*r2,
    E = 4*s*Y*r2,
    F = (s2 - 4*(X2 + Y2))*r2;

  // this is the rotation matrix
  return mat4.fromValues(
    A, B, C, 0,
    B, D, E, 0,
    -C,-E, F, 0,
    0, 0, 0, 1
  );
}

let mouseMove = function(event,webgl) {

  if (!webgl.dragging) return;

  // compute the rotatation matrix from the last point on the sphere to the new point
  let R = rotation( -(event.pageX-webgl.lastX)/webgl.canvas.width , -(event.pageY-webgl.lastY)/webgl.canvas.height );
  mat4.multiply( webgl.modelMatrix , R , webgl.modelMatrix );

  // redraw and set the last state as the new one
  webgl.draw();
  webgl.lastX = event.pageX;
  webgl.lastY = event.pageY;
}

let mouseDown = function(event,webgl) {
  // set that dragging is true and save the last state
  webgl.dragging = true;
  webgl.lastX    = event.pageX;
  webgl.lastY    = event.pageY;
}

let mouseUp = function(event,webgl) {
  // dragging is now false
  webgl.dragging = false;
}

let mouseWheel = function(event,webgl) {
  event.preventDefault();

  let scale = 1.0;
  if (event.deltaY > 0) scale = 0.9;
  else if (event.deltaY < 0) scale = 1.1;

  // scale the direction from the model center to the eye
  let direction = vec3.create();
  vec3.subtract( direction , webgl.eye , webgl.mesh.center );
  vec3.scaleAndAdd( webgl.eye , webgl.mesh.center , direction , scale );

  webgl.draw();
}

function Indexer() {
  this.unique  = [];
  this.indices = [];
  this.map     = {};
}

Indexer.prototype = {
  add: function(obj) {
    var key = JSON.stringify(obj);
    if (!(key in this.map)) {
      this.map[key] = this.unique.length;
      this.unique.push(obj);
    }
    return this.map[key];
  }
};

function computeWireframe(mesh){
  const nt = mesh.triangles.length/3;
  let indexer = new Indexer();
  for (var i = 0; i < nt; i++) {
    for (var j = 0; j < 3; j++) {
      const p = mesh.triangles[3*i+j];
      const q = mesh.triangles[3*i+(j+1)%3];
      indexer.add([Math.min(p, q), Math.max(p,q)]);
    }
  }
  mesh.edges = reshapeArray(indexer.unique);
}

function computeNormals(vertices,triangles) {
	const np = vertices.length/3;
	const nt = triangles.length/3;

	// allocate the data
  valency = new Uint8Array(np);
  normals = new Float32Array(vertices.length);

  // add the contribution of every triangle to the vertices
  for (var i = 0; i < nt; i++) {
    // retrieve the indices of the triangle and add the valency contributions
    const t0 = triangles[3*i  ];
    const t1 = triangles[3*i+1];
    const t2 = triangles[3*i+2];

    // retrieve the coordinates of the points
    const p0x = vertices[ 3*t0    ];
    const p0y = vertices[ 3*t0 +1 ];
    const p0z = vertices[ 3*t0 +2 ];
    const p1x = vertices[ 3*t1    ];
    const p1y = vertices[ 3*t1 +1 ];
    const p1z = vertices[ 3*t1 +2 ];
    const p2x = vertices[ 3*t2    ];
    const p2y = vertices[ 3*t2 +1 ];
    const p2z = vertices[ 3*t2 +2 ];

    const ux = p1x - p0x;
    const uy = p1y - p0y;
    const uz = p1z - p0z;
    const vx = p2x - p0x;
    const vy = p2y - p0y;
    const vz = p2z - p0z;

    // compute the triangle normal
    let nx = uy*vz - uz*vy;
    let ny = uz*vx - ux*vz;
    let nz = ux*vy - uy*vx;

    // add the contribution to every vertex
    normals[3*t0] += nx; normals[3*t0+1] += ny; normals[3*t0+2] += nz;
    normals[3*t1] += nx; normals[3*t1+1] += ny; normals[3*t1+2] += nz;
    normals[3*t2] += nx; normals[3*t2+1] += ny; normals[3*t2+2] += nz;

    valency[t0]++;
    valency[t1]++;
    valency[t2]++;
  }

  // average the point normals
  for (var i = 0; i < np; i++) {
    // compute the average
    normals[3*i  ] /= valency[i];
    normals[3*i+1] /= valency[i];
    normals[3*i+2] /= valency[i];

    // normalize
    const nx = normals[3*i];
    const ny = normals[3*i+1];
    const nz = normals[3*i+2];

    const n = Math.sqrt( nx*nx + ny*ny + nz*nz );
    normals[3*i  ] /= n;
    normals[3*i+1] /= n;
    normals[3*i+2] /= n;
  }
	return normals;
}

let reshapeArray = function(rawData) {
  let data = [];
  for (var i = 0, chunk = 10000; i < rawData.length; i += chunk) {
    data = Array.prototype.concat.apply(data, rawData.slice(i, i + chunk));
  }
  return data;
}

let preprocess = function( mesh ) {

  // compute the edges
  computeWireframe(mesh);

  // compute bounding box
  const big = 1e10;
  let xmin = big, xmax = -big;
  let ymin = big, ymax = -big;
  let zmin = big, zmax = -big;
  for (let i = 0; i < mesh.vertices.length/3; i++)
  {
    const x = mesh.vertices[3*i];
    const y = mesh.vertices[3*i+1];
    const z = mesh.vertices[3*i+2];

    if (x < xmin) xmin = x;
    if (x > xmax) xmax = x;
    if (y < ymin) ymin = y;
    if (y > ymax) ymax = y;
    if (z < zmin) zmin = z;
    if (z > zmax) zmax = z;
  }
  mesh.center  = vec3.fromValues( .5*(xmin+xmax) , .5*(ymin+ymax) , .5*(zmin+zmax) );
	mesh.normals = computeNormals( mesh.vertices , mesh.triangles );

  // translate the model to the origin (this makes life easier)
  for (let i = 0; i < mesh.vertices.length/3; i++) {
    mesh.vertices[3*i  ] -= mesh.center[0];
    mesh.vertices[3*i+1] -= mesh.center[1];
    mesh.vertices[3*i+2] -= mesh.center[2];
  }
  mesh.center = vec3.create();
  mesh.size = xmax - xmin;
  if (ymax-ymin > mesh.size) mesh.size = ymax-ymin;
  if (zmax-zmin > mesh.size) mesh.size = zmax-zmin;
}
