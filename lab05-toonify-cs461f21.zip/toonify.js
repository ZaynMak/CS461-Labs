function WebGLRenderer(canvas_id) {

  this.canvas = document.getElementById(canvas_id);

  // get the context handle for rendering webgl in the canvas
  this.gl = this.canvas.getContext("webgl") || canvas.getContext("experimental-webgl");

  // set the resolution of the context to match the canvas
  this.gl.viewport(0,0,this.canvas.width, this.canvas.height);

  // Complete the vertex shader and fragment shader sources!
  let vertexShaderSource = `
    attribute vec4 a_Position;
    attribute vec3 a_Normal;

    // uniforms in case you need them
    uniform mat4 u_ProjectionMatrix;
    uniform mat4 u_ViewMatrix;
    uniform mat4 u_ModelMatrix;
    uniform mat4 u_NormalMatrix;
    uniform vec3 u_Camera; // camera position in case you need it

		varying vec3 v_Normal;
		varying vec3 v_Position;
		varying vec3 v_Light;

    /*
      some useful functions might include:

      mat3(): extracts upper-left 3x3 submatrix of a mat4
      .xyz: returns the first three components of a vec4, as a vec3
      abs(): absolute value of some float
      normalize(): normalize some input vector (i.e. make it a unit vector)
      reflect(v,n): calculates v - 2*dot(n,v)*n
      dot(u,v): returns the dot product of u and v (u.v)
      length(u): returns the length of a vector u

      NOTE: if you shader program doesn't compile, you will see an error message
            in the console with the compiler error. Please check this!

      See the GLSL reference card:
        https://www.khronos.org/files/webgl/webgl-reference-card-1_0.pdf
    */

    void main() {
      gl_Position  = u_ProjectionMatrix * u_ViewMatrix * u_ModelMatrix * a_Position;

      // transform the normal (a_Normal)
      v_Normal = mat3(u_NormalMatrix) * a_Normal;

      // do we need to pass the position to the fragment shader?
      v_Position = vec3(u_ViewMatrix * u_ModelMatrix * a_Position);

    }`;
  let fragmentShaderSource = `
    precision highp float;

		varying vec3 v_Normal;
		varying vec3 v_Position;
		vec3 v_Light;
    
    uniform vec3 u_Camera; // camera position in case you need it

    uniform int u_silhouette; // should we draw the silhouette? (u_silhouette > 0 means True)
    uniform int u_phong;      // should we ONLY use the phong model? (u_phong > 0 means True)

    vec3 color = vec3(1,1,0);

    void main() {
			vec3 n = normalize(v_Normal);
  		v_Light = vec3(-v_Position);
			v_Light = normalize(v_Light);
			
      // should we draw the silhouette?
      if (u_silhouette > 0) {
        // yes, return black if this is a point on the silhouette
      }

      // calculate ambient (ca), diffuse (cd) and specular (cs) color components here
			// calculating ambient lighting
  		vec3 ka = 0.4*color;
  		vec3 La = vec3(1.0); // makes ambient light color white
  		vec3 ca = ka*La;

			// calculating diffuse reflection
			float diffuse = max(0.0, dot(v_Light, n)); // try abs instead of max later


			vec3 kd = color;
			vec3 Ld = vec3(1.0);
			vec3 cd = kd*Ld*diffuse;

			// calculating specular reflection
			vec3 r = -reflect(v_Light,n);
			float specular = pow( max( 0.0 , dot(r,n) ), 32.0 );
			vec3 ks = vec3(1.0);
			vec3 Ls = vec3(1.0);
			vec3 cs = ks*Ls*specular;

			vec3 c = ca + cd + cs;
      // note that c = k*L where k is a vec3 (color) and L is a vec3 (color)
      // will return some vec3 c, where k and L are multiplied component-wise
      // feel free to define the coefficients ka, kd, ks, La, Ld, Ls as you wish (get artistic!)

      // should we only return the phong model?
      if (u_phong > 0) {
        // yes, return the color from the phong model
				gl_FragColor = vec4(c,1.0);
      }

      // if we made it here, then we should "toonify" the result
      // which can be achieved by "banding" the color from the phong model
      // using the length of the color we obtained from the phong model

    }`;

  // create the shader program
  this.program = compileProgram( this.gl , vertexShaderSource , fragmentShaderSource );

  // create the project matrix
  this.projectionMatrix = mat4.create();
  mat4.perspective( this.projectionMatrix , Math.PI/4.0 , this.canvas.width/this.canvas.height , 0.01 , 10000.0 );

  // create the model matrix (identity)
  this.modelMatrix = mat4.create();

  // create the view matrix
  this.eye        = vec3.fromValues(-1,3,-5); // overwritten in write function
  this.viewMatrix = mat4.create();

  // set the view and projection matrix uniforms
  this.gl.useProgram( this.program );
  this.gl.uniformMatrix4fv( this.gl.getUniformLocation(this.program,'u_ProjectionMatrix'), false, this.projectionMatrix );
  this.gl.uniformMatrix4fv( this.gl.getUniformLocation(this.program,'u_ViewMatrix'), false, this.viewMatrix );

  // setup the callbacks
  this.dragging = false;
  let webgl = this;
  this.canvas.addEventListener( 'mousemove' ,  function(event) { mouseMove(event,webgl); } );
  this.canvas.addEventListener( 'mousedown' ,  function(event) { mouseDown(event,webgl); } );
  this.canvas.addEventListener( 'mouseup' ,    function(event) { mouseUp(event,webgl); } );
  this.canvas.addEventListener( 'mousewheel' , function(event) { mouseWheel(event,webgl);} );
}

WebGLRenderer.prototype.write = function( mesh ) {

  // create a buffer for the vertices
  this.vertexBuffer = this.gl.createBuffer();
  this.gl.bindBuffer( this.gl.ARRAY_BUFFER , this.vertexBuffer );
  this.gl.bufferData( this.gl.ARRAY_BUFFER , new Float32Array(mesh.vertices) , this.gl.STATIC_DRAW );

  // enable the position attribute
  let aPosition = this.gl.getAttribLocation(this.program,'a_Position');
  this.gl.vertexAttribPointer( aPosition , 3 , this.gl.FLOAT , false , 0 , 0 );
  this.gl.enableVertexAttribArray(aPosition);

  this.normalBuffer = this.gl.createBuffer();
  this.gl.bindBuffer( this.gl.ARRAY_BUFFER , this.normalBuffer );
  this.gl.bufferData( this.gl.ARRAY_BUFFER , new Float32Array(mesh.normals) , this.gl.STATIC_DRAW );

  // enable the normal attribute
  let aNormal = this.gl.getAttribLocation(this.program,'a_Normal');
  this.gl.vertexAttribPointer( aNormal , 3 , this.gl.FLOAT , false , 0 , 0 );
  this.gl.enableVertexAttribArray(aNormal);

  // create a buffer for the triangles
  this.triangleBuffer = this.gl.createBuffer();
  this.gl.bindBuffer( this.gl.ELEMENT_ARRAY_BUFFER , this.triangleBuffer );
  this.gl.bufferData( this.gl.ELEMENT_ARRAY_BUFFER , new Uint16Array(mesh.triangles) , this.gl.STATIC_DRAW );

  // place the eye a little further away from the center of the mesh
  // according to the size of the mesh (largest size in any dimension)
  let dir = vec3.fromValues(0,0,-1);
  vec3.scaleAndAdd( this.eye , mesh.center , dir , 3*mesh.size );
  this.eye[1] = mesh.size;

  // save the mesh
  this.mesh = mesh;
}

WebGLRenderer.prototype.draw = function() {

  // clear the canvas for drawing
  this.gl.clearColor(.8,.8,.8,1);
  this.gl.clear(this.gl.COLOR_BUFFER_BIT | this.gl.DEPTH_BUFFER_BIT);
  this.gl.enable( this.gl.DEPTH_TEST );
  this.gl.enable( this.gl.CULL_FACE );
  this.gl.useProgram( this.program );

  // set the shader type
  this.gl.uniform1i( this.gl.getUniformLocation(this.program,'u_phong') , this.phong );
  this.gl.uniform1i( this.gl.getUniformLocation(this.program,'u_silhouette') , this.silhouette );

  // compute the view matrix
  this.center = this.mesh.center.slice();
  mat4.lookAt( this.viewMatrix , this.eye , this.center , vec3.fromValues(0,1,0) );

  // set the uniform for the model matrix and view matrix
  this.gl.uniformMatrix4fv( this.gl.getUniformLocation(this.program,'u_ModelMatrix'), false, this.modelMatrix );
  this.gl.uniformMatrix4fv( this.gl.getUniformLocation(this.program,'u_ViewMatrix'), false, this.viewMatrix );

  // send the camera position to the shader
  let uCamera = this.gl.getUniformLocation( this.program , 'u_Camera' );
  this.gl.uniform3fv( uCamera , this.eye );



  // send the normal matrix to the shader
  let normalMatrix = mat4.create();
  mat4.multiply( normalMatrix , this.viewMatrix , this.modelMatrix );
  mat4.invert( normalMatrix , normalMatrix );
  mat4.transpose( normalMatrix , normalMatrix );
  this.gl.uniformMatrix4fv( this.gl.getUniformLocation(this.program,'u_NormalMatrix'), false, normalMatrix );

  // draw the triangles
  this.gl.bindBuffer( this.gl.ELEMENT_ARRAY_BUFFER , this.triangleBuffer );
  this.gl.drawElements( this.gl.TRIANGLES , this.mesh.triangles.length , this.gl.UNSIGNED_SHORT , 0 );
}
