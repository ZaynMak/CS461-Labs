function BirdAnimation(canvasID) {

  // initialize webgl
  this.canvas = document.getElementById(canvasID);
  this.gl = this.canvas.getContext('webgl') || this.canvas.getContext('experimental-webgl');

  // set the resolution of the context to match the canvas
  this.gl.viewport(0,0,this.canvas.width, this.canvas.height);

  const vertexShaderSource = `

    attribute vec3 a_Position;
    attribute vec3 a_Normal;
    attribute vec2 a_Parameter;

    uniform mat4 u_ProjectionMatrix;
    uniform mat4 u_ViewMatrix;
    uniform mat4 u_ModelMatrix;
    uniform mat4 u_NormalMatrix;

    uniform float u_alpha;
    uniform vec3 u_center;
    uniform int u_wing;

    varying vec2 v_Parameter;
    varying vec3 v_Position;

    #define PI 3.141592654

    void main() {
      gl_Position  = u_ProjectionMatrix * u_ViewMatrix * u_ModelMatrix * vec4(a_Position,1.0);
      v_Parameter  = a_Parameter;

      // to deform the skin of the wings, see the equation in the lab to compute the suggested
      // 'displacement' relative to a_Position (or come up with your own!)
      // recall some useful GLSL functions you used in lab 05
      // you may need to pass some uniforms in the 'BirdAnimation.prototype.draw' function

      if (u_wing == 1) {
        vec3 axis = vec3(0, 1.0, -1.0);
        vec3 displacement = 0.5*length(a_Position - u_center)*length(a_Position - u_center)*sin(u_alpha - PI/6.0)*sin(u_alpha + 2.0*PI/3.0)*axis;

        gl_Position = u_ProjectionMatrix * u_ViewMatrix * u_ModelMatrix * (vec4(a_Position + displacement, 1.0));
      }

			
    }`;
  const fragmentShaderSource = `
    precision highp float;

    varying vec2 v_Parameter;
    uniform sampler2D tex_Color;

    void main() {
      vec3 color = vec3(texture2D(tex_Color,v_Parameter));
      gl_FragColor = vec4(color,1.0);
    }`;

  // create the shader program
  this.program = compileProgram( this.gl , vertexShaderSource , fragmentShaderSource );

  // load the meshes
  this.meshes = [];
  this.meshes.push( loadMesh(hummingbird_body) );
  this.meshes.push( loadMesh(hummingbird_wingL) );
  this.meshes.push( loadMesh(hummingbird_wingR) );

  this.eye    = vec3.fromValues(0,-3,-5);
  this.center = vec3.create(); // origin
  this.viewMatrix = mat4.create();
  mat4.lookAt( this.viewMatrix , this.eye , this.center , vec3.fromValues(0,1,0) );

  this.projectionMatrix = mat4.create();
  mat4.perspective( this.projectionMatrix , Math.PI/4.0 , this.canvas.width/this.canvas.height , 0.1 , 1000.0 );

  this.angle = 0;

  // setup the callbacks
  this.dragging = false;
  let renderer = this;
  this.canvas.addEventListener( 'mousemove' ,  function(event) { mouseMove(event,renderer); } );
  this.canvas.addEventListener( 'mousedown' ,  function(event) { mouseDown(event,renderer); } );
  this.canvas.addEventListener( 'mouseup' ,    function(event) { mouseUp(event,renderer); } );
  this.canvas.addEventListener( 'mousewheel' , function(event) { mouseWheel(event,renderer);} );
}

BirdAnimation.prototype.write = function(canvasID) {

  // so that we don't have to write this.gl all the time
  let gl = this.gl;

  for (let i = 0; i < this.meshes.length; i++) {

    // create a buffer for the vertices
    this.meshes[i].positionBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER , this.meshes[i].positionBuffer );
    gl.bufferData( gl.ARRAY_BUFFER , new Float32Array(this.meshes[i].vertices) , gl.STATIC_DRAW );

    this.meshes[i].normalBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER , this.meshes[i].normalBuffer );
    gl.bufferData( gl.ARRAY_BUFFER , new Float32Array(this.meshes[i].normals) , gl.STATIC_DRAW );

    // create a buffer for the triangles
    this.meshes[i].triangleBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ELEMENT_ARRAY_BUFFER , this.meshes[i].triangleBuffer );
    gl.bufferData( gl.ELEMENT_ARRAY_BUFFER , new Uint16Array(this.meshes[i].triangles) , gl.STATIC_DRAW );

    // create a buffer for the vertex parameter coordinates
    this.meshes[i].parameterBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER , this.meshes[i].parameterBuffer );
    gl.bufferData( gl.ARRAY_BUFFER , new Float32Array(this.meshes[i].params) , gl.STATIC_DRAW );

    // initialize the model matrix of this mesh to the identity matrix
    this.meshes[i].modelMatrix = mat4.create();
  }

  // setup the textures
  setupImageTexture(gl,this.program,'hummingbird-color','tex_Color',0,true);
}

BirdAnimation.prototype.draw = function() {

  let gl = this.gl;

  // clear the canvas and enable the attributes
  gl.useProgram( this.program );
  gl.clearColor(0.2,0,0.8, 0.4);
  gl.clear(this.gl.COLOR_BUFFER_BIT | this.gl.DEPTH_BUFFER_BIT);
  gl.enable( gl.DEPTH_TEST );
  gl.enable( gl.CULL_FACE );

  // set the uniforms
  gl.uniformMatrix4fv( gl.getUniformLocation(this.program,'u_ProjectionMatrix'), false, this.projectionMatrix );
  gl.uniformMatrix4fv( gl.getUniformLocation(this.program,'u_ViewMatrix'), false, this.viewMatrix );

  for (let i = 0; i < this.meshes.length; i++) {

    // set the uniform for the model matrix of this mesh
    gl.uniformMatrix4fv( gl.getUniformLocation(this.program,'u_ModelMatrix'), false, this.meshes[i].modelMatrix );

    if (this.meshes[i].name == 'wingL' || this.meshes[i].name == 'wingR') {
			gl.uniform3fv(gl.getUniformLocation(this.program,'u_center'),this.meshes[i].center);
			gl.uniform1f(gl.getUniformLocation(this.program,'u_alpha'),(this.angle*Math.PI/180));
			gl.uniform1i(gl.getUniformLocation(this.program,'u_wing'), 1);
		} else {
			gl.uniform1i(gl.getUniformLocation(this.program,'u_wing'), 0);
		}

    gl.bindBuffer(gl.ARRAY_BUFFER, this.meshes[i].positionBuffer);
    let aPosition = gl.getAttribLocation(this.program,'a_Position');
    gl.vertexAttribPointer( aPosition , 3 , gl.FLOAT , false , 0 , 0 );
    gl.enableVertexAttribArray(aPosition);

    gl.bindBuffer(gl.ARRAY_BUFFER, this.meshes[i].normalBuffer);
    let aNormal = gl.getAttribLocation(this.program,'a_Normal');
		gl.vertexAttribPointer(aNormal, 3 , gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(aNormal);

    gl.bindBuffer(gl.ARRAY_BUFFER, this.meshes[i].parameterBuffer);
    let aParameter = gl.getAttribLocation(this.program,'a_Parameter');
		gl.vertexAttribPointer(aParameter, 2 , gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(aParameter);

    // set the normal matrix
    let normalMatrix = mat4.create();
    mat4.multiply( normalMatrix , this.viewMatrix , this.meshes[i].modelMatrix );
    mat4.invert( normalMatrix , normalMatrix );
    mat4.transpose( normalMatrix , normalMatrix );
    gl.uniformMatrix4fv( gl.getUniformLocation(this.program,'u_NormalMatrix'), false, normalMatrix );

    // draw the triangles
    gl.bindBuffer( gl.ELEMENT_ARRAY_BUFFER , this.meshes[i].triangleBuffer );
    gl.drawElements( gl.TRIANGLES , this.meshes[i].triangles.length , gl.UNSIGNED_SHORT , 0 );
  }
}

BirdAnimation.prototype.setAngle = function(angleDegrees) {
  /**
   * Rotates the wingL and wingR meshes by some angleDegrees from the binding pose.
   * Updates the modelMatrix (by compounding) the rotation from the last angle to the current angle.
   * In other words, you should only rotate by the difference between the current angle and the last angle
   * (this is computed for you in the variable 'dangle', i.e. the "delta angle", below).
   * @returns none, but this.angle is updated to the input angleDegrees, and model matrices of meshes are updated.
   * 
   * Note: The meshes are available in this.meshes
   *       Access the i'th mesh with this.meshes[i]
   *       - the left wing mesh has the attribute this.meshes[i].name == 'wingL'
   *       - the right wing mesh has the attribute this.meshes[i].name == 'wingR'
   *       - the body mesh has the attribute this.meshes[i].name == 'body'
   * 
   * (see the last line in model/wingL.js, model/wingR.js and model/body.js for more info)
   * 
   * The wingL and wingR meshes have the attributes meshes[i].center and meshes[i].axis
   * representing the center of rotation, as well as the axis of rotation.
   * Recall the lecture exercise for performing this transformation.
  **/

  // the variable dangle represents how much you want to rotate
  let dangle = (angleDegrees - this.angle)*Math.PI/180.; // change in angle from previous pose in radians
  this.angle = angleDegrees; // current angle in degrees

  for (let i = 0; i < this.meshes.length; i++) {

    if (this.meshes[i].name == 'wingL' || this.meshes[i].name == 'wingR') {
      
      let center = this.meshes[i].center;
      let axis = this.meshes[i].axis;
      let transformation = mat4.create();
      
      // compute the transformation here
      let T = mat4.create();
      mat4.fromTranslation(T, center);

      let Tinv = mat4.create();
      mat4.invert( Tinv , T );

      let R = mat4.create();
      mat4.fromRotation(R, dangle, axis);

      mat4.multiply(transformation, R, Tinv);
      mat4.multiply(transformation, T, transformation);

      // modify the model matrix
      mat4.multiply(this.meshes[i].modelMatrix,this.meshes[i].modelMatrix,transformation);
    }
  }

  this.draw();
}