function compileShader(gl, shaderSource, type) {
  let shader = gl.createShader(type);
  gl.shaderSource(shader, shaderSource);
  gl.compileShader(shader);

  if (! gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    var error = gl.getShaderInfoLog(shader);
    gl.deleteShader(shader);
    throw "Unable to compile " + (type === gl.VERTEX_SHADER ? 'vertex': 'fragment') + " shader: " + error;
  }

  return shader;
}

function compileProgram( gl , vertexShaderSource , fragmentShaderSource ) {

  let vertexShader = compileShader(gl, vertexShaderSource, gl.VERTEX_SHADER);
  let fragmentShader = compileShader(gl, fragmentShaderSource, gl.FRAGMENT_SHADER);

  let program = gl.createProgram();
  gl.attachShader(program, vertexShader);
  gl.attachShader(program, fragmentShader);

  gl.linkProgram(program);

  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    throw "Unable to compile the shader program: " + gl.getProgramInfoLog(program);
  }

  gl.useProgram(program);
  return program;
}

// computes a rotation matrix of a vector (X,Y) on the unit sphere using quaternions
function rotation(X, Y) {
  let X2 = X*X, Y2 = Y*Y,
    q  = 1 + X2 + Y2,
    s  = 1 - X2 - Y2,
    r2 = 1/(q*q), s2 = s*s,
    A = (s2 + 4*(Y2 - X2))*r2,
    B = -8*X*Y*r2,
    C = 4*s*X*r2,
    D = (s2 + 4*(X2 - Y2))*r2,
    E = 4*s*Y*r2,
    F = (s2 - 4*(X2 + Y2))*r2;

  // this is the rotation matrix
  return mat4.fromValues(
    A, B, C, 0,
    B, D, E, 0,
    -C,-E, F, 0,
    0, 0, 0, 1
  );
}

let mouseMove = function(event,webgl) {

  if (!webgl.dragging) return;

  // compute the rotatation matrix from the last point on the sphere to the new point
  let R = rotation( -(event.pageX-webgl.lastX)/webgl.canvas.width , -(event.pageY-webgl.lastY)/webgl.canvas.height );

  for (let i = 0; i < webgl.meshes.length; i++)
    mat4.multiply( webgl.meshes[i].modelMatrix , R , webgl.meshes[i].modelMatrix );

  // redraw and set the last state as the new one
  webgl.draw();
  webgl.lastX = event.pageX;
  webgl.lastY = event.pageY;
}

let mouseDown = function(event,webgl) {
  // set that dragging is true and save the last state
  webgl.dragging = true;
  webgl.lastX    = event.pageX;
  webgl.lastY    = event.pageY;
}

let mouseUp = function(event,webgl) {
  // dragging is now false
  webgl.dragging = false;
}

let mouseWheel = function(event,webgl) {
  event.preventDefault();

  let scale = 1.0;
  if (event.deltaY > 0) scale = 0.9;
  else if (event.deltaY < 0) scale = 1.1;

  // scale the direction from the model center to the eye
  let direction = vec3.create();
  vec3.subtract( direction , webgl.eye , webgl.center );
  vec3.scaleAndAdd( webgl.eye , webgl.center , direction , scale );

  mat4.lookAt( webgl.viewMatrix , webgl.eye , webgl.center , vec3.fromValues(0,1,0) );
  webgl.draw();
}


function loadMesh(component) {

  let mesh = {};
  mesh.vertices = component.vertices;
  mesh.normals  = component.normals;
  mesh.params   = component.uv;
  mesh.name = component.name;

  mesh.triangles = [];
  let k = 0;
  for (let i = 0; i < mesh.vertices.length/9; i++) {
    mesh.triangles.push(k,k+1,k+2);
    k += 3;
  }

  // comute the center and axis of connection
  if (component.connection != undefined) {
    const p0 = component.connection.slice(0,3);
    const p1 = component.connection.slice(3,6);
    const p2 = component.connection.slice(6,9);
    const p3 = component.connection.slice(9,12);

    mesh.axis = vec3.create();
    mesh.center = vec3.create();

    for (let d = 0; d < 3; d++) {
      mesh.axis[d]   = 0.5*(p0[d]+p2[d]) - 0.5*(p1[d]+p3[d]);
      mesh.center[d] = 0.25*(p0[d]+p1[d]+p2[d]+p3[d]);
      if (component.name == 'wingL') mesh.axis[d] *= -1.0;
    }
    //console.log(mesh.axis,mesh.center);
  }

  return mesh;
}

function setupImageTexture( gl , program , imageID , uniformName , index , flip ) {

  // retrieve the image
  let image = document.getElementById(imageID);

  // create the texture and activate it
  let texture = gl.createTexture();
  gl.activeTexture(gl.TEXTURE0 + index );
  gl.bindTexture( gl.TEXTURE_2D, texture );

  // define the texture to be that of the requested image
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, flip);
  gl.texImage2D( gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, image );

  // generate the mipmap and filters
  gl.generateMipmap( gl.TEXTURE_2D );
  gl.texParameteri( gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST_MIPMAP_LINEAR );
  gl.texParameteri( gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST );

  // tell webgl which texture index to use for the uniform sampler2D in the shader
  // you will need a 'uniform sampler2D uniformName' to use the texture within your shader
  gl.uniform1i( gl.getUniformLocation(program, uniformName) , index );
}