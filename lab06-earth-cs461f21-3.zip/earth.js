function WebGLEarth(canvasID) {

  // initialize webgl
  this.canvas = document.getElementById(canvasID);
  this.gl = this.canvas.getContext('webgl') || this.canvas.getContext('experimental-webgl');

  // set the resolution of the context to match the canvas
  this.gl.viewport(0,0,this.canvas.width, this.canvas.height);

  const vertexShaderSource = `

    attribute vec3 a_Position;  // (x,y,z) position on unit sphere
    attribute vec2 a_Parameter; // (u,v) coordinates for every vertex, in [0,1]
    // hmmm the attribute a_Normal is not passed in...
    // (hint: you do NOT need to compute normals on JavaScript side and pass them in)

    // uniforms you might need
    uniform mat4 u_ProjectionMatrix;
    uniform mat4 u_ViewMatrix;
    uniform mat4 u_ModelMatrix;
    uniform mat4 u_NormalMatrix;

    // texture samplers you might need
    uniform sampler2D tex_Color; // use this to get color of the earth (see exercise in notes)
    uniform sampler2D tex_Bump;  // use this to bump earth's surface

    // varyings you may wish to pass to the fragment shader
    varying vec3 v_Normal;
    varying vec3 v_Position;
    varying vec2 v_Parameter;
		varying vec3 v_Light;


    void main() {
      gl_Position  = u_ProjectionMatrix * u_ViewMatrix * u_ModelMatrix * vec4(a_Position,1.0);

			v_Parameter = a_Parameter;

      v_Position = (u_ViewMatrix * u_ModelMatrix *  vec4(a_Position,1.0)).xyz;
      v_Normal = mat3(u_NormalMatrix) * a_Position;


    }`;
  const fragmentShaderSource = `
    precision highp float;

    // varyings you may wish to receive from the vertex shader
    varying vec3 v_Normal;
    varying vec3 v_Position;
    varying vec2 v_Parameter;
		vec3 v_Light;
    

    // texture samplers you might need
    uniform sampler2D tex_Color; // use this to get color of the earth (see exercise in notes)
    uniform sampler2D tex_Bump;  // use this to bump earth's surface

    void main() {
			vec4 final_color = texture2D(tex_Color, v_Parameter);

			vec3 n = normalize(v_Normal);
      v_Light = vec3(-v_Position);
			v_Light = normalize(v_Light);

			float diffuse = max(0.0, dot(v_Light, n));
			vec3 kd = vec3(final_color);
			vec3 Ld = vec3(1.0);
			vec3 cd = kd*Ld*diffuse;


			final_color = final_color + vec4(cd, 0.0);


			gl_FragColor = final_color;
			
			
    }`;

  // create the shader program
  this.program = compileProgram( this.gl , vertexShaderSource , fragmentShaderSource );

  // save the mesh
  let sphere = getSphereMesh(200,200);
  this.points = sphere.vertices.slice();
  this.triangles = sphere.triangles.slice();
  this.params = sphere.params.slice();
  //console.log(this.params.slice(80600));

  this.eye         = vec3.fromValues(-1,3,-5);
  this.center      = vec3.create(); // origin
  this.modelMatrix = mat4.create();
  this.viewMatrix  = mat4.create();
  mat4.lookAt( this.viewMatrix , this.eye , this.center , vec3.fromValues(0,1,0) );

  this.projectionMatrix = mat4.create();
  mat4.perspective( this.projectionMatrix , Math.PI/4.0 , this.canvas.width/this.canvas.height , 0.1 , 1000.0 );

  // setup the callbacks
  this.dragging = false;
  let renderer = this;
  this.canvas.addEventListener( 'mousemove' ,  function(event) { mouseMove(event,renderer); } );
  this.canvas.addEventListener( 'mousedown' ,  function(event) { mouseDown(event,renderer); } );
  this.canvas.addEventListener( 'mouseup' ,    function(event) { mouseUp(event,renderer); } );
  this.canvas.addEventListener( 'mousewheel' , function(event) { mouseWheel(event,renderer);} );
}

function setupImageTexture( gl , program , imageID , uniformName , index ) {

  // retrieve the image
  let image = document.getElementById(imageID);

  // create the texture and activate it
  let texture = gl.createTexture();
  gl.activeTexture(gl.TEXTURE0 + index );
  gl.bindTexture( gl.TEXTURE_2D, texture );

  // define the texture to be that of the requested image
  gl.texImage2D( gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, image );

  // generate the mipmap and filters
  gl.generateMipmap( gl.TEXTURE_2D );
  gl.texParameteri( gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST_MIPMAP_LINEAR );
  gl.texParameteri( gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST );

  // tell webgl which texture index to use for the uniform sampler2D in the shader
  // you will need a 'uniform sampler2D uniformName' to use the texture within your shader
  gl.uniform1i( gl.getUniformLocation(program, uniformName) , index );
}

WebGLEarth.prototype.write = function(canvasID) {

  // dereference to make life easier
  let gl = this.gl;

  // create a buffer for the vertices
  this.vertexBuffer = gl.createBuffer();
  gl.bindBuffer( gl.ARRAY_BUFFER , this.vertexBuffer );
  gl.bufferData( gl.ARRAY_BUFFER , new Float32Array(this.points) , gl.STATIC_DRAW );

  // enable the position attribute
  let aPosition = gl.getAttribLocation(this.program,'a_Position');
  gl.vertexAttribPointer( aPosition , 3 , gl.FLOAT , false , 0 , 0 );
  gl.enableVertexAttribArray(aPosition);

  // create a buffer for the triangles
  this.triangleBuffer = gl.createBuffer();
  gl.bindBuffer( gl.ELEMENT_ARRAY_BUFFER , this.triangleBuffer );
  gl.bufferData( gl.ELEMENT_ARRAY_BUFFER , new Uint16Array(this.triangles) , gl.STATIC_DRAW );

  // create a buffer for the vertex parameter coordinates
  this.parameterBuffer = gl.createBuffer();
  gl.bindBuffer( gl.ARRAY_BUFFER , this.parameterBuffer );
  gl.bufferData( gl.ARRAY_BUFFER , new Float32Array(this.params) , gl.STATIC_DRAW );

  // enable the parameter coordinates attribute
  let aParameter = gl.getAttribLocation(this.program,'a_Parameter');
  gl.bindBuffer( gl.ARRAY_BUFFER , this.parameterBuffer );
  gl.vertexAttribPointer( aParameter , 2, gl.FLOAT, false, 0, 0 );
  gl.enableVertexAttribArray(aParameter);

  // setup the textures
  setupImageTexture(gl,this.program,'earth-color','tex_Color',0);
  setupImageTexture(gl,this.program,'earth-bump','tex_Bump',1);
}

WebGLEarth.prototype.draw = function() {

  let gl = this.gl;

  // clear the canvas and enable the attributes
  gl.useProgram( this.program );
  gl.clearColor(0.1,0.1,0.1, 1.0);
  gl.clear(this.gl.COLOR_BUFFER_BIT | this.gl.DEPTH_BUFFER_BIT);
  gl.enable( gl.DEPTH_TEST );
  gl.enable( gl.CULL_FACE );

  // set the uniforms
  gl.uniformMatrix4fv( gl.getUniformLocation(this.program,'u_ProjectionMatrix'), false, this.projectionMatrix );
  gl.uniformMatrix4fv( gl.getUniformLocation(this.program,'u_ViewMatrix'), false, this.viewMatrix );
  gl.uniformMatrix4fv( gl.getUniformLocation(this.program,'u_ModelMatrix'), false, this.modelMatrix );

  // set the normal matrix
  let normalMatrix = mat4.create();
  mat4.multiply( normalMatrix , this.viewMatrix , this.modelMatrix );
  mat4.invert( normalMatrix , normalMatrix );
  mat4.transpose( normalMatrix , normalMatrix );
  gl.uniformMatrix4fv( gl.getUniformLocation(this.program,'u_NormalMatrix'), false, normalMatrix );

  // draw the triangles
  gl.bindBuffer( gl.ELEMENT_ARRAY_BUFFER , this.triangleBuffer );
  gl.drawElements( gl.TRIANGLES , this.triangles.length , gl.UNSIGNED_SHORT , 0 );
}
