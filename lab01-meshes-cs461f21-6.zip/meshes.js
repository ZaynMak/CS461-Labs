function Plotter() {
  // retrieve the HTML canvas with the id 'canvas-mesh'
  this.canvas  = document.getElementById('canvas-mesh');

  // retrieve the context we will use to draw
  // here, we use the '2d' context (later we will use the 'webgl' context)
  this.context = this.canvas.getContext('2d');

  // whether to plot the bounding box or not
  this.bbox = true;
}

Plotter.prototype.load = function() {
  // retrieve the mesh we want to load from the dropdown
  // you can hard-code this to 'square' as you debug
  let meshName = document.getElementById('mesh-dropdown').value;

  if (meshName == 'square') {
    this.vertices  = [50.0,50.0,450.0,50.0,450.0,450.0,50.0,450.0];
    this.triangles = [0,1,2,0,2,3];
  }
  else if (meshName == 'mystery') {
    // the variable 'mystery' is loaded in the head section of the HTML document.
    // it is stored as a JSON with the fields 'vertices' and 'triangles'.
    // we will represent a lot of externally generated meshes using this format.
    this.vertices  = mystery.vertices;
    this.triangles = mystery.triangles;
  }
  else {
    alert('unknown mesh name ',meshName);
  }
}

Plotter.prototype.draw = function() {
  
  const big = 1e10; // some huge value

  // clear the canvas
  this.context.clearRect(0,0,this.canvas.width,this.canvas.height);

  // get the limits of the bounding box
  const nb_vertices = this.vertices.length / 2;
  let xmin = big, xmax = -big;
  let ymin = big, ymax = -big;
  for (let i = 0; i < nb_vertices; i++) {
    const x = this.vertices[2*i];
    const y = this.vertices[2*i+1];

    if (x < xmin) xmin = x;
    if (x > xmax) xmax = x;
    if (y < ymin) ymin = y;
    if (y > ymax) ymax = y;
  }

  // draw the bounding box
  if (this.bbox) {
    this.context.beginPath();
    this.context.strokeColor = 'grey';
    this.context.moveTo( xmin , ymin );
    this.context.lineTo( xmax , ymin );
    this.context.lineTo( xmax , ymax );
    this.context.lineTo( xmin , ymax );
    this.context.lineTo( xmin , ymin );
    this.context.stroke();
  }

  // draw the triangle edges and fill the triangles with random colors
  const nb_triangles = this.triangles.length / 3;

  // your code goes here!
  for(let i = 0; i < nb_triangles; i++){
    this.context.beginPath();
    this.context.strokeColor = 'grey';
		
		const ax = this.vertices[2 * this.triangles[i*3]];
		const ay = this.vertices[(2 * this.triangles[(i*3)]) + 1];
  	
		this.context.moveTo( ax , ay );
		
		const bx = this.vertices[2 * this.triangles[(i*3) + 1]];
		const by = this.vertices[(2 * this.triangles[(i*3) + 1] + 1)];

    this.context.lineTo( bx, by );

		const cx = this.vertices[2 * this.triangles[(i*3) + 2]];
		const cy = this.vertices[(2 * this.triangles[(i*3) + 2]) + 1];

		this.context.lineTo( cx, cy );

		this.context.lineTo( ax, ay );
    
    const colors = ['LightCoral', 'blue', 'navy', 'yellow', 'green', ' black', 'Silver']
		this.context.fillStyle = colors[Math.floor(Math.random() * 7)];

    this.context.fill();
	  this.context.stroke();

    // add triangle number at centroid
    const centroid_x = (ax + bx + cx) / 3;
    const centroid_y = (ay + by + cy) / 3;

		this.context.fillStyle = "black";
    this.context.fillText(i.toString(), centroid_x, centroid_y);


  }

	for (let i = 0; i < nb_vertices; i++){
		x = this.vertices[2*i];
		y = this.vertices[(2*i)+1]
		this.context.beginPath();
  	this.context.arc(x, y, 5, 0, 2 * Math.PI, true);
		this.context.fillStyle = "black";
    this.context.fillText(i.toString(), x + 5, y + 5);
  	this.context.fill();
	}
}