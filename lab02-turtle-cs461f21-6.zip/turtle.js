function Turtle(canvas_id) {
  // get the canvas and 2d context
  this.canvas  = document.getElementById(canvas_id);
  this.context = this.canvas.getContext('2d');

  // set the canvas width as 100%
  this.canvas.width = window.innerWidth;
  this.canvas.height = this.canvas.width; // aspect ratio of 1.0

  // clear whatever was drawn before
  this.context.clearRect(0,0,this.canvas.width,this.canvas.height);

  // initialize the transformation to a translation to somewhere on the canvas
  this.transform = mat3.fromValues(
    1 , 0 , 0 , // first column
    0 , 1 , 0 , // second column
    this.canvas.width/4.0 , this.canvas.height/2.0 , 1.0 // third column
  );
  this.point = vec3.create(); //the origin
  this.point[2] = 1.0; // homogeneous coordinates
  vec3.transformMat3( this.point , this.point , this.transform );

  // move to the initial point
  this.context.moveTo( this.point[0] , this.point[1] );

  // this is meant to emulate the turtle.pendown() feature which only
  // draws a line if the pen is down
  this.pendown = true;
}

Turtle.prototype.forward = function( length ) {
  // implement!

	const translation = mat3.fromValues(
    1 , 0 , 0 , // first column
    0 , 1 , 0 , // second column
    length , 0 , 1 // third column
  );

  //Composed transformation matrix
  mat3.multiply(this.transform, this.transform, translation);

  this.context.beginPath();
  this.context.moveTo(this.point[0], this.point[1]);

	// applies the new transformation and creates origin with homogeneous coordinates (0, 0, 1)
  origin = vec3.fromValues(0,0,1); 
  vec3.transformMat3(this.point, origin, this.transform);

  if (this.pendown){
    this.context.lineTo(this.point[0], this.point[1]);
  } else{
    this.context.moveTo(this.point[0], this.point[1]);
  }
	this.context.stroke();
}


Turtle.prototype.left = function( angle ) {
  // implement!
	// rotates the direction of the turtle counterclockwise by rad

	const rad = angle * Math.PI / 180;

  // define turtle-context rotation
  let rotation = mat3.fromValues(
    Math.cos(rad), -Math.sin(rad), 0,
		Math.sin(rad), Math.cos(rad), 0,
		0, 0, 1
  );

  // multiply by existing transformation
  mat3.multiply(this.transform, this.transform, rotation);

  origin = vec3.fromValues(0,0,1); 
	vec3.transformMat3(this.point, origin, this.transform);
}


Turtle.prototype.back = function( length ) {
  this.forward(-length);
}

Turtle.prototype.right = function( angle ) {
  // just call left with the negative angle!
  this.left(-angle);
}

function drawSquare( turtle, length ) {
  // draws an equilateral triangle using the provided turtle
  
  turtle.forward(length);
  turtle.left(90);
  turtle.forward(length);
  turtle.left(90);
  turtle.forward(length);
  turtle.left(90);
  turtle.forward(length);

}

function drawTriangle( turtle, length ) {
  // draws an equilateral triangle using the provided turtle
  turtle.forward(length);
  turtle.left(120);
  turtle.forward(length);
  turtle.left(120);
  turtle.forward(length);
}

function drawTree( turtle , length ) {

  // this might look familiar to anyone who has taken CS 200 with me :)
  let angle = 20;
  if (length < 1.0)
    return;

  turtle.forward(length);

  turtle.left(angle);
  drawTree(turtle,length/2);

  turtle.left(angle);
  drawTree(turtle,length/2);

  turtle.right(3*angle);
  drawTree(turtle,length/2);

  turtle.right(angle);
  drawTree(turtle,length/2);

  turtle.left(2*angle);
  turtle.back(length);
}

function drawSierpinski( turtle , length , generations ) {
  if (generations == 0)
    return;

  drawSierpinski( turtle , length / 2 , generations-1 );
  turtle.forward(length);
  turtle.left(120);

  drawSierpinski( turtle , length / 2 , generations-1 );
  turtle.forward(length);
  turtle.left(120);

  drawSierpinski( turtle , length/2 , generations-1 );
  turtle.forward(length);
  turtle.left(120);
}

function drawRandomGraphics(turtle, length, generations, current){
  if (current == generations + 1){
    return;
  }
  current++

  turtle.left(60);
  turtle.forward(length / Math.pow(3, generations));

  drawRandomGraphics(turtle, length, generations, current);
  turtle.right(120);
  turtle.forward(length / Math.pow(3, generations));

  drawRandomGraphics(turtle, length, generations, current);
  turtle.right(120);
  turtle.forward(length / Math.pow(3, generations));

}
