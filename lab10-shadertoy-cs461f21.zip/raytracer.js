function RayTracer( canvasID , fs_src ) {

  this.canvas = document.getElementById(canvasID);
  this.gl = this.canvas.getContext('webgl') || this.canvas.getContext('experimental-webgl');

  // set the resolution of the context to match the canvas
  this.gl.viewport(0,0,this.canvas.width, this.canvas.height);

  let vs_src = `
    attribute vec2 a_Position;
    void main() {
      gl_Position = vec4(a_Position,0.,1.);
    }
  `;

  console.assert( fs_src != undefined );
  this.program = compileProgram( this.gl , vs_src , fs_src );

  // set up a full screen quad
  let vertices  = [-1,-1,1,-1,1,1,-1,1];
  let triangles = [0,1,2,0,2,3];

  let gl = this.gl;
  this.vertex_buffer = gl.createBuffer();
  gl.bindBuffer( gl.ARRAY_BUFFER , this.vertex_buffer );
  gl.bufferData( gl.ARRAY_BUFFER , new Float32Array(vertices) , gl.STATIC_DRAW );

  let a_Position = gl.getAttribLocation( this.program , 'a_Position' );
  gl.vertexAttribPointer( a_Position , 2 , gl.FLOAT , false , 0 , 0 );
  gl.enableVertexAttribArray(a_Position);

  this.triangle_buffer = gl.createBuffer();
  gl.bindBuffer( gl.ELEMENT_ARRAY_BUFFER , this.triangle_buffer );
  gl.bufferData( gl.ELEMENT_ARRAY_BUFFER , new Uint16Array(triangles) , gl.STATIC_DRAW );

  // initialize time
  this.u_time = 0.0;
}

RayTracer.prototype.render = function() {

  let gl = this.gl;
  gl.useProgram( this.program );

  // write the uniforms
  this.u_time += dt/50.;
  this.gl.uniform1f( gl.getUniformLocation( this.program , 'u_time' ) , this.u_time );
  this.gl.uniform1f( gl.getUniformLocation( this.program , 'u_width' ) , this.canvas.width );
  this.gl.uniform1f( gl.getUniformLocation( this.program , 'u_height' ) , this.canvas.height );

  // draw the full screen quad
  gl.bindBuffer( gl.ELEMENT_ARRAY_BUFFER , this.triangle_buffer );
  gl.drawElements( gl.TRIANGLES , 6 , gl.UNSIGNED_SHORT , 0 );
}

function compileShader(gl, shaderSource, type) {
  let shader = gl.createShader(type);
  gl.shaderSource(shader, shaderSource);
  gl.compileShader(shader);

  if (! gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    var error = gl.getShaderInfoLog(shader);
    gl.deleteShader(shader);
    throw "Unable to compile " + (type === gl.VERTEX_SHADER ? 'vertex': 'fragment') + " shader: " + error;
  }

  return shader;
}

function compileProgram( gl , vertexShaderSource , fragmentShaderSource ) {

  let vertexShader = compileShader(gl, vertexShaderSource, gl.VERTEX_SHADER);
  let fragmentShader = compileShader(gl, fragmentShaderSource, gl.FRAGMENT_SHADER);

  let program = gl.createProgram();
  gl.attachShader(program, vertexShader);
  gl.attachShader(program, fragmentShader);

  gl.linkProgram(program);

  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    throw "Unable to compile the shader program: " + gl.getProgramInfoLog(program);
  }

  gl.useProgram(program);
  return program;
}
