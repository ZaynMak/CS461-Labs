function Point(x,mass) {
  this.current  = x.slice(); // vec2
  this.previous = x.slice(); // vec2
  this.mass     = mass;      // mass at this point
  this.inverse_mass = 1./mass; // saves repeated divisions during simulation
  this.dt = 5e-3; // time step
  this.fext = vec2.fromValues(0.0,-9.81*mass); // external force (downwards force of gravity)
}

Point.prototype.move = function() {
  /**
   * Moves the point according to the external force (stored in this.fext).
   * @returns nothing but (1) sets this.previous to be the old coordinate (this.current)
   *  and (2) updates this.current to the new location using the formula below.
   *
   * recall the formula is: x^{k+1} = 2*x^k - x^{k-1} + fext*dt^2/m
   * here: fext    = this.fext (vec2)
   *       x^k     = this.current (vec2)
   *       x^{k-1} = this.previous (vec2)
   *       dt      = this.dt (scalar)
   *       m       = this.mass (scalar)
   */

  let updated_position = vec2.create();
  vec2.scale(updated_position, this.current, 2);
  vec2.subtract(updated_position, updated_position,this.previous);

  let force_term = vec2.create();
  vec2.scale(force_term, this.fext, this.dt);
  vec2.scale(force_term, force_term, this.dt);
  vec2.scale(force_term, force_term, this.inverse_mass);
  
  vec2.add(updated_position, updated_position, force_term);

  this.previous = this.current.slice();
  this.current = updated_position.slice();
}

Point.prototype.draw = function(canvas,context,transformation) {
  const radius = 5;
  const twopi = Math.PI*2.0;
  context.beginPath();
  let q = vec2.create();
  vec2.transformMat3( q , this.current , transformation );
  context.arc( q[0] , q[1] , radius , twopi , false );
  context.fill();
}

function Constraint(p,q) {
  this.p = p; // a Point object above, which has coordinates this.p.current (a vec2)
  this.q = q; // a Point object above, which has coordinates this.q.current (a vec2)
  this.rest_length = vec2.distance( p.current , q.current ); // scalar rest length of the spring
}

Constraint.prototype.satisfy = function() {
  /**
   * Attempts to satisfy the constraints on this edge
   * by restoring the spring to its rest_length.
   * this.p and this.q are both Point objects which store 'current' coordinates (vec2) and mass (scalar)
   * Your job is to update the 'current' coordinates using the formula in the reading notes (see the pseudocode for the constraint update). DO NOT the previous coordinates.
   * @returns nothing, but edge endpoint coordinates (this.p.current and this.q.current are updated, both are vec2's)
   *
   * notation in the notes:
   *    L0 = this.rest_length (scalar)
   *    p0 = this.p.current (vec2)
   *    p1 = this.q.current (vec2)
   *    m0 = this.p.mass (or 1/m0 = this.p.inverse_mass)
   *    m1 = this.q.mass (or 1/m1 = this.q.inverse_mass)
  **/
	let delta = (vec2.distance(this.q.current, this.p.current) - this.rest_length)/vec2.distance(this.q.current, this.p.current); // p0 and p1 are the constraint (edge) endpoint coordinates (vectors)
	let dx = vec2.create();
	vec2.sub(dx, this.q.current, this.p.current);
  vec2.scale(dx, dx, delta); 

	let mt = this.p.mass * this.q.mass / (this.p.mass + this.q.mass); // m0 and m1 are the masses of particles p0 and p1
	let temp = vec2.create();
	vec2.add(this.p.current, this.p.current, vec2.scale(temp, dx, mt*this.p.inverse_mass));
	vec2.sub(this.q.current, this.q.current, vec2.scale(temp, dx, mt*this.q.inverse_mass)); 
}

Constraint.prototype.draw = function(canvas,context,transformation) {
  context.beginPath()
  let p = vec2.create();
  vec2.transformMat3( p , this.p.current , transformation );
  context.moveTo(p[0],p[1]);
  vec2.transformMat3( p , this.q.current , transformation );
  context.lineTo(p[0],p[1]);
  context.stroke();
}

function ClothAnimation(canvasID,nx,ny) {

  // save the canvas and context
  this.canvas = document.getElementById(canvasID);
  this.context = this.canvas.getContext('2d');

  // save the incoming parameters
  this.nx = nx;
  this.ny = ny;

  // initialize the array of points and constraints
  this.points = [];
  this.constraints = [];

  // transformation from [-1,1] x [-1,1] to screen space
  let w = this.canvas.width;
  let h = this.canvas.height;
  this.screen_matrix = mat3.fromValues(
    w/2 , 0 , 0 ,
    0 , -h/2 , 0 ,
    (w-1)/2 , (h-1)/2 , 1.
  );

  // initialize the points (get_points is defined in utils.min.js)
  const mass = 0.05;
  let points = get_points( nx , ny , [-0.5,-0.25] , 1.0 , 1.0 );
  for (let i = 0; i < points.length; i++) {
    this.points.push( new Point(points[i],mass) );
  }

  // initialize edges (get_edges is defined in utils.min.js)
  let edges = get_edges(nx,ny);
  for (let i = 0; i < edges.length/2; i++) {
    let p = this.points[ edges[2*i  ] ];
    let q = this.points[ edges[2*i+1] ];
    this.constraints.push( new Constraint(p,q) );
  }

  // set the fixed points to have a zero inverse mass (a mass of infinity)
  // pick either points at the top, or on the left side
  // (these functions are defined in utils.min.js)
  let fixed = get_top_three_point_indices( nx , ny );
  //let fixed = get_left_three_point_indices( nx , ny );
  for (let i = 0; i < fixed.length; i++)
    this.points[ fixed[i] ].inverse_mass = 0.0;

  // mouse controls for clicking and dragging
  function mouseDown(event) {
    // we are setting a callback of the canvas, so 'this' is a canvas
    const rect = this.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    console.log('mouse clicked at = (',x,',',y,')'); 
  }

  function mouseUp(event) {
    console.log('mouse was released!');
  }

  function mouseMove(event) {
    // we are setting a callback of the canvas, so 'this' is a canvas
    const rect = this.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    //console.log('mouse location = (',x,',',y,')');    
  }

  // set the callbacks
  this.canvas.onmousedown = mouseDown;
  this.canvas.onmousemove = mouseMove;
  this.canvas.onmouseup   = mouseUp;
}

ClothAnimation.prototype.update = function() {
  /**
   * Updates the cloth by (1) moving the points and (2) satisfying the constraints
  **/

  let nb_iter = 2; // investigate here!
  for (let iter = 0; iter < nb_iter; iter++) {

    // move each point according to external forces
    for (let i = 0 ; i < this.points.length; i++)
      this.points[i].move();

    // compute the constraints on the edges
    for (let i = 0; i < this.constraints.length; i++)
      this.constraints[i].satisfy();

    this.draw();
  }
}

ClothAnimation.prototype.draw = function() {
  /**
   * Draws the cloth at the current time step.
  **/

  // clear the canvas
  this.context.clearRect(0,0,this.canvas.width,this.canvas.height);

  // draw the constraints
  for (let i = 0; i < this.constraints.length; i++)
    this.constraints[i].draw(this.canvas,this.context,this.screen_matrix);

  // draw the poitns
  for (let i = 0; i < this.points.length; i++)
    this.points[i].draw(this.canvas,this.context,this.screen_matrix);
}
