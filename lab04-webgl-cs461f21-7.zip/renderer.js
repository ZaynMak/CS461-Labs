function getShader(gl,type,source) {

	// set shader source and compile
	var shader = gl.createShader(type);
	gl.shaderSource(shader, source);
	gl.compileShader(shader);

	// check if there was an error
	if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
		alert(gl.getShaderInfoLog(shader));
		return undefined;
	}

	return shader;
}

function createProgram(gl, vertexShaderSource, fragmentShaderSource) {

	var vertexShader = getShader(gl, gl.VERTEX_SHADER,  vertexShaderSource );
	var fragmentShader = getShader(gl, gl.FRAGMENT_SHADER,fragmentShaderSource);

	var program = gl.createProgram();
	gl.attachShader(program, vertexShader);
	gl.attachShader(program, fragmentShader);
	gl.linkProgram(program);

	if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
	  alert("could not link shader program.");
	}
	gl.useProgram(program);

	return program;
}

function WebGLRenderer(canvasID) {

  // retrieve the canvas
  this.canvas = document.getElementById(canvasID);

  // retrieve the gl context
  this.gl = this.canvas.getContext('webgl') || this.canvas.getContext('experimental-webgl');

  // define the vertex shader source (a string)
  let vertex_shader_source = `
  attribute vec3 a_Position;
  attribute vec3 a_Color;

  uniform mat4 u_PerspectiveMatrix;
  uniform mat4 u_ViewMatrix;
  uniform mat4 u_ModelMatrix;

	
  //pass vertex color to the fragment shader
  varying vec3 v_Color;

  void main(void) {
		
	  gl_Position = u_PerspectiveMatrix * u_ViewMatrix * u_ModelMatrix * vec4(a_Position, 1.0 );

		v_Color = a_Color;
		
  }`;

  // define the fragment shader source (a string)
  let fragment_shader_source = `
  precision highp float;

	varying vec3 v_Color;

  uniform int u_edges;

  void main(void) {
    if (u_edges < 0)
	    gl_FragColor = vec4(v_Color,1.0);
    else
      gl_FragColor = vec4(0.0,0.0,0.0,1.0);
	
  }`;

  // compile our shader program
  this.program = createProgram(this.gl,vertex_shader_source,fragment_shader_source);
}

WebGLRenderer.prototype.load = function() {

    // retrieve the mesh we want to load from the dropdown
  let meshName = document.getElementById('mesh-dropdown').value;

  // pick the mesh and select the view parameters for that mesh
  if (meshName == 'square') {
    // retrieve the mesh of a square (i.e. 2 triangles)
    this.mesh   = { 'dim': 3 , 'vertices': [0,0,0,1,0,0,1,1,0,0,1,0] , 'triangles': [0,1,2,0,2,3], 'edges': [0,1,0,2,1,2,2,3,0,3], 'colors': [0.8,0.8,0.2,0.8,0.8,0.2,0.8,0.8,0.2,0.8,0.8,0.2] };
  }
  else if (meshName = 'box') {

    this.mesh   = { 'dim': 3 , 'vertices':
    [
      0,0,0,
      1,0,0,
      1,1,0,
      0,1,0,
      0,0,1,
      1,0,1,
      1,1,1,
      0,1,1
    ] ,
    'triangles':
    [
      0,1,2, 0,2,3,
      5,4,6, 4,7,6,
      1,5,6, 1,6,2,
      4,0,3, 4,3,7,
      4,5,1, 4,1,0,
      3,2,6, 3,6,7
    ] ,
    'edges':
    [
			0,1,
			1,2,
			2,3,
			3,0,
			0,4,
			4,5,
			5,1,
			3,7,
			6,7,
			6,2,
			4,7,
			5,6
    ] ,
    'colors':
    [
      1,0,0,
      0,1,0,
      0,0,1,
      0.6,0,0.4,
			0.5,0.5,0,
			0.5,0,0.5,
			0,0.5,0.5,
      0,1,1
    ]
  };
  }
  else {
    alert('unknown mesh name ', meshName);
  }

  // initialize model matrix to the identity matrix
  this.model_matrix = mat4.create();
}

WebGLRenderer.prototype.setup = function() {

  let gl = this.gl; // dereference the context to make life easier
  let mesh = this.mesh;
	
  // create a buffer for the coordinates and write the vertex coordinates to it
  this.vertexBuffer = gl.createBuffer();
  gl.bindBuffer( gl.ARRAY_BUFFER , this.vertexBuffer );
  gl.bufferData( gl.ARRAY_BUFFER , new Float32Array(mesh.vertices) , gl.STATIC_DRAW );

	// create a buffer for the colors and write the colors array to it
  this.colorBuffer = gl.createBuffer();
  gl.bindBuffer( gl.ARRAY_BUFFER , this.colorBuffer );
  gl.bufferData( gl.ARRAY_BUFFER , new Float32Array(mesh.colors) , gl.STATIC_DRAW );

  // create a buffer for the triangles and write the triangle indices to it
  this.triangleBuffer = gl.createBuffer();
  gl.bindBuffer( gl.ELEMENT_ARRAY_BUFFER , this.triangleBuffer );
  gl.bufferData( gl.ELEMENT_ARRAY_BUFFER , new Uint16Array(mesh.triangles) , gl.STATIC_DRAW );

  // only create an edge buffer if the mesh edges are defined
  if (mesh.edges != undefined) {
    // create a buffer for the edges and write the edge indices to it
    this.edgeBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ELEMENT_ARRAY_BUFFER , this.edgeBuffer );
    gl.bufferData( gl.ELEMENT_ARRAY_BUFFER , new Uint16Array(mesh.edges) , gl.STATIC_DRAW );
  }
  else {
    this.edgeBuffer = undefined;
  }

  // save the position attribute location
  this.positionAttribute = gl.getAttribLocation( this.program , 'a_Position' );
  gl.enableVertexAttribArray( this.positionAttribute );

	a_Color = gl.getAttribLocation(this.program,'a_Color');
	 // enable the color attribute in the shader program (at attribute a_Color)
  gl.vertexAttribPointer( a_Color , 3 , gl.FLOAT , false , 0 , 0 );
  gl.enableVertexAttribArray(a_Color);
}

WebGLRenderer.prototype.draw  = function() {

  let gl = this.gl;

  // setup the viewport and clear screen
  gl.viewport(0, 0, this.canvas.width, this.canvas.height);
	gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

  // setup the view matrix
  let center = vec3.fromValues(0.5,0.5,0.0);0
  let eye = vec3.fromValues(1.5,0.5,-2.0);
  let viewMatrix = mat4.create();1
  mat4.lookAt( viewMatrix , eye , center , vec3.fromValues(0,1,0) );

  // setup the perspective matrix
  let perspectiveMatrix = mat4.create();
  mat4.perspective( perspectiveMatrix , Math.PI/2.0 , this.canvas.width/this.canvas.height , 0.01 , 1000.0 );
  
  // send the matrices to the shader program
  let u_mv = gl.getUniformLocation( this.program , 'u_ViewMatrix' );
  let u_mp = gl.getUniformLocation( this.program , 'u_PerspectiveMatrix' );
  let u_mm = gl.getUniformLocation( this.program , 'u_ModelMatrix' );
  
  gl.uniformMatrix4fv( u_mv , false , viewMatrix );
  gl.uniformMatrix4fv( u_mp , false , perspectiveMatrix );
  gl.uniformMatrix4fv( u_mm , false , this.model_matrix );


  // bind the data in the vertexBuffer to the positionAttribute
  gl.bindBuffer( gl.ARRAY_BUFFER , this.vertexBuffer );
  gl.vertexAttribPointer(this.positionAttribute, 3 , gl.FLOAT, false, 0, 0);

  // retrieve the location of the uniform that controls whether we are drawing edges
  let u_edges = gl.getUniformLocation( this.program , 'u_edges');

  // draw the triangles
  gl.uniform1i( u_edges , -1 );
  gl.bindBuffer( gl.ELEMENT_ARRAY_BUFFER , this.triangleBuffer );
  gl.drawElements( gl.TRIANGLES , this.mesh.triangles.length , gl.UNSIGNED_SHORT , 0 );

  // draw the edges if the edge buffer exists
  if (this.edgeBuffer != undefined) {
    gl.uniform1i( u_edges , 1 );
    gl.bindBuffer( gl.ELEMENT_ARRAY_BUFFER , this.edgeBuffer );
    gl.drawElements( gl.LINES , this.mesh.edges.length , gl.UNSIGNED_SHORT , 0 );
  }

}
